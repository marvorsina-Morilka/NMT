export enum TaskKind {
  TASK_1_MATCHING_ADS = 'task1',
  TASK_2_READING_MCQ = 'task2',
  TASK_3_MATCHING_TEXTS = 'task3',
  TASK_4_GAP_FILL_CLAUSES = 'task4',
  TASK_5_USE_OF_ENGLISH_VOCAB = 'task5',
  TASK_6_USE_OF_ENGLISH_GRAMMAR = 'task6',
}

export interface LetterOption {
  letter: string;
  text: string;
}

export interface McqQuestion {
  num: number;
  text?: string;
  options: LetterOption[];
  correct: string;
}

export interface Task1Test {
  id: number;
  title: string;
  texts: {
    id: number;
    title: string;
    text: string;
  }[];
  options: LetterOption[];
  keys: Record<number, string>;
}

export interface Task2Test {
  id: number;
  title: string;
  paragraphs: string[];
  questions: McqQuestion[];
}

export interface Task3Test {
  id: number;
  title: string;
  items: {
    num: number;
    name: string;
    text: string;
  }[];
  choices: LetterOption[];
  correct: Record<number, string>;
}

export interface Task4Test {
  id: number;
  title: string;
  paragraphs: string[];
  choices: LetterOption[];
  correct: Record<number, string>;
}

export interface Task56Test {
  id: number;
  title: string;
  text: string;
  questions: McqQuestion[];
}

export interface AdventThemeConfig {
  id: TaskKind;
  adventNumber: number;
  taskNumber: number;
  themeName: string;
  subtitle: string;
  ukrainianTitle: string;
  taskFormatLabel: string;
  questionRangeLabel: string;
  totalTests: number;
  pointsPerTest: number;
  maxPoints: number;
  coverImage: string;
  doorMotifLabel: string;
  accentHex: string;
  accentSoftHex: string;
  accentBorderHex: string;
  accentTextHex: string;
  badgeTextHex: string;
  description: string;
}

export type UserAnswersMap = Record<string, Record<number, string>>;
export type CheckedMap = Record<string, boolean>;
export type ShuffleSeedMap = Record<string, number>;
