import React, { useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  Check,
  Image as ImageIcon,
  LayoutGrid,
  Shuffle,
} from 'lucide-react';
import { ADVENTS_CONFIG, getAdventConfig } from '../data/adventsMeta';
import { CheckedMap, ShuffleSeedMap, TaskKind, UserAnswersMap } from '../types/nmt';
import {
  calculateAdventStats,
  calculateSingleTestScore,
  getTestTitle,
  makeTestKey,
} from '../utils/nmtHelpers';
import { VintageDoorMotif } from './VintageDoorMotifs';

interface AdventCalendarGridProps {
  adventKind: TaskKind;
  userAnswers: UserAnswersMap;
  checkedMap: CheckedMap;
  shuffleMap: ShuffleSeedMap;
  onSelectAdvent: (kind: TaskKind) => void;
  onOpenDoor: (kind: TaskKind, testId: number) => void;
  onReshuffleAdvent: (kind: TaskKind) => void;
  onBackOverview: () => void;
}

type DoorStyleVariant = 'stamp' | 'airmail' | 'suitcase-primary' | 'suitcase-secondary';

function getDoorStyleVariant(dayNum: number): DoorStyleVariant {
  // Matches the rhythmic variety in the 1950s reference poster (stamps, suitcases, airmail cards)
  const pattern: DoorStyleVariant[] = [
    'stamp',
    'airmail',
    'stamp',
    'suitcase-secondary',
    'suitcase-primary',
    'stamp',
    'suitcase-secondary',
    'stamp',
    'stamp',
    'suitcase-primary',
    'stamp',
    'suitcase-secondary',
    'airmail',
    'suitcase-secondary',
    'suitcase-primary',
    'stamp',
  ];
  return pattern[(dayNum - 1) % pattern.length];
}

function getSuitcaseColors(kind: TaskKind): { primaryBg: string; secondaryBg: string } {
  switch (kind) {
    case TaskKind.TASK_1_MATCHING_ADS:
      return { primaryBg: '#991B1B', secondaryBg: '#1E5B70' }; // Cherry red & vintage teal (matches reference)
    case TaskKind.TASK_2_READING_MCQ:
      return { primaryBg: '#881337', secondaryBg: '#5C3A21' }; // Cherry & espresso brown
    case TaskKind.TASK_3_MATCHING_TEXTS:
      return { primaryBg: '#3F6212', secondaryBg: '#9D4E59' }; // Olive sage & dusty rose
    case TaskKind.TASK_4_GAP_FILL_CLAUSES:
      return { primaryBg: '#7F1D1D', secondaryBg: '#1E4631' }; // Burgundy & forest green
    case TaskKind.TASK_5_USE_OF_ENGLISH_VOCAB:
      return { primaryBg: '#0F4C75', secondaryBg: '#B84A52' }; // Navy & coral pink
    case TaskKind.TASK_6_USE_OF_ENGLISH_GRAMMAR:
      return { primaryBg: '#312E81', secondaryBg: '#5B21B6' }; // Midnight indigo & cosmic violet
  }
}

export const AdventCalendarGrid: React.FC<AdventCalendarGridProps> = ({
  adventKind,
  userAnswers,
  checkedMap,
  shuffleMap,
  onSelectAdvent,
  onOpenDoor,
  onReshuffleAdvent,
  onBackOverview,
}) => {
  const config = getAdventConfig(adventKind);
  const stats = calculateAdventStats(adventKind, userAnswers, checkedMap, shuffleMap);
  const [imgFailed, setImgFailed] = useState(false);
  const [useInteractiveRefPoster, setUseInteractiveRefPoster] = useState(false);

  const doors = Array.from({ length: config.totalTests }, (_, idx) => idx + 1);
  const suitcaseColors = getSuitcaseColors(config.id);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBackOverview}
          className="inline-flex items-center gap-2 text-sm font-semibold text-stone-600 hover:text-stone-950 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Усі 6 адвентів</span>
        </button>

        <div
          className="flex items-center gap-1 p-1 bg-stone-200/70 rounded-lg overflow-x-auto max-w-full"
          role="tablist"
          aria-label="Перемикач адвент-календарів"
        >
          {ADVENTS_CONFIG.map((item) => {
            const active = item.id === adventKind;
            return (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => {
                  setImgFailed(false);
                  setUseInteractiveRefPoster(false);
                  onSelectAdvent(item.id);
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-white text-stone-950 shadow-sm'
                    : 'text-stone-600 hover:text-stone-950'
                }`}
              >
                Адвент {item.adventNumber} · Task {item.taskNumber}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main 1950s Vintage Poster Container modeled directly on image_68e72c4c.png */}
      <section
        aria-label={`Постер ${config.themeName}`}
        className="bg-[#F5EBD6] border-2 border-[#CBB389] rounded-3xl p-4 sm:p-6 lg:p-8 shadow-sm space-y-6"
      >
        {/* Top Arched Vintage Signboard Plaque */}
        <div className="flex flex-col items-center">
          <div className="w-full max-w-3xl bg-[#FFFDF7] border-2 border-[#BFA374] rounded-[28px] px-6 py-4 sm:py-5 text-center shadow-xs relative">
            <div className="text-[11px] sm:text-xs font-bold uppercase tracking-widest text-stone-500 mb-1 tabular-nums">
              Адвент {config.adventNumber} · {config.themeName} · {config.questionRangeLabel}
            </div>
            <h1 className="font-display italic font-bold text-3xl sm:text-4xl lg:text-[42px] text-[#1D3557] leading-none">
              English Advent Calendar
            </h1>
            <p className="text-xs sm:text-sm font-medium text-stone-600 mt-2">
              {config.ukrainianTitle} — 31 віконечко (сітка 4 × 8)
            </p>
          </div>
        </div>

        {/* Optional Toggle for Advent 1 to interact directly with the uploaded example poster */}
        {adventKind === TaskKind.TASK_1_MATCHING_ADS && (
          <div className="flex flex-wrap items-center justify-between gap-3 bg-[#FAF4E8] border border-[#D4BD94] rounded-xl px-4 py-2.5">
            <span className="text-xs sm:text-sm text-stone-700 font-medium">
              Режим відображення Адвенту 1: перемикайтеся між сіткою віконець та інтерактивним постером-зразком
            </span>
            <div className="flex items-center gap-1 p-1 bg-[#E9DAC0] rounded-lg">
              <button
                type="button"
                onClick={() => setUseInteractiveRefPoster(false)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer transition-colors ${
                  !useInteractiveRefPoster
                    ? 'bg-white text-stone-950 shadow-xs'
                    : 'text-stone-700 hover:text-stone-950'
                }`}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>Сітка з темами</span>
              </button>
              <button
                type="button"
                onClick={() => setUseInteractiveRefPoster(true)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer transition-colors ${
                  useInteractiveRefPoster
                    ? 'bg-white text-stone-950 shadow-xs'
                    : 'text-stone-700 hover:text-stone-950'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Постер-зразок</span>
              </button>
            </div>
          </div>
        )}

        {useInteractiveRefPoster && adventKind === TaskKind.TASK_1_MATCHING_ADS ? (
          <div className="flex flex-col items-center space-y-4">
            <div className="relative w-full max-w-2xl rounded-2xl overflow-hidden border-2 border-[#BFA374] bg-[#FAF4E8]">
              <img
                src="/assets/aistudio/image_68e72c4c.png"
                alt="Інтерактивний постер English Advent Calendar"
                referrerPolicy="no-referrer"
                className="w-full h-auto block select-none"
              />
              {/* Interactive clickable hotspots mapped precisely onto doors 1-30 */}
              <div
                className="absolute grid grid-cols-4 grid-rows-8 gap-[1.3%]"
                style={{
                  left: '38%',
                  top: '19.5%',
                  width: '60%',
                  height: '74%',
                }}
              >
                {doors.map((dayNum) => {
                  const key = makeTestKey(config.id, dayNum);
                  const isChecked = Boolean(checkedMap[key]);
                  const scoreInfo = calculateSingleTestScore(
                    config.id,
                    dayNum,
                    userAnswers,
                    shuffleMap
                  );

                  return (
                    <button
                      key={dayNum}
                      type="button"
                      onClick={() => onOpenDoor(config.id, dayNum)}
                      title={`День ${dayNum}: ${getTestTitle(config.id, dayNum, shuffleMap[key] ?? 0)}`}
                      className={`relative rounded-md transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300 ${
                        isChecked
                          ? 'bg-emerald-900/20 ring-2 ring-emerald-400 hover:bg-emerald-900/30'
                          : 'hover:bg-amber-200/30 hover:ring-2 hover:ring-amber-300'
                      }`}
                    >
                      {isChecked && (
                        <span className="absolute bottom-1 right-1 bg-emerald-700 text-white font-mono text-[10px] font-bold px-1.5 py-0.5 rounded shadow-xs tabular-nums">
                          {scoreInfo.score}/{scoreInfo.total}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
            <p className="text-xs text-stone-600 text-center">
              Натисніть на будь-яку валізу чи марку (1–31) прямо на постері, щоб відкрити відповідний тест НМТ.
            </p>
          </div>
        ) : (
          /* Two-Column Poster Layout mirroring image_68e72c4c.png */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            {/* Left Poster Showcase Column */}
            <aside className="lg:col-span-4 flex flex-col justify-between gap-5 bg-[#FAF4E8] border-2 border-[#CBB389] rounded-2xl p-5">
              <div className="space-y-4">
                <div className="rounded-xl overflow-hidden border border-[#CBB389] bg-stone-100 aspect-[3/4]">
                  {!imgFailed ? (
                    <img
                      src={config.coverImage}
                      alt={config.themeName}
                      referrerPolicy="no-referrer"
                      onError={() => setImgFailed(true)}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div
                      className="w-full h-full flex flex-col items-center justify-center p-4 text-center"
                      style={{ backgroundColor: config.accentSoftHex }}
                    >
                      <BookOpen className="w-8 h-8 mb-2" style={{ color: config.accentTextHex }} />
                      <span className="font-display font-bold text-base text-stone-900">
                        {config.themeName}
                      </span>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <h2 className="font-display text-xl font-bold text-stone-950">
                    {config.themeName}
                  </h2>
                  <p className="text-sm text-stone-700 leading-relaxed">{config.description}</p>
                </div>

                <div className="bg-white border border-[#D8C49E] rounded-xl p-4 space-y-2.5">
                  <div className="flex items-center justify-between text-xs font-semibold text-stone-600 tabular-nums">
                    <span>
                      Відкрито: {stats.completedTests} / {stats.totalTests}
                    </span>
                    <span className="font-mono font-bold text-stone-950">
                      {stats.earnedPoints} / {stats.maxPoints} балів
                    </span>
                  </div>
                  <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
                    <div
                      className="h-full transition-all duration-300"
                      style={{ width: `${stats.percent}%`, backgroundColor: config.accentHex }}
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onReshuffleAdvent(config.id)}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-stone-300 bg-white hover:bg-stone-50 text-stone-800 text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
                >
                  <Shuffle className="w-4 h-4" />
                  <span>Перемішати відповіді в адвенті</span>
                </button>
              </div>

              {/* Vintage 3-Book Stack inspired directly by bottom-right corner of image_68e72c4c.png */}
              <div className="pt-4 border-t border-[#E2D1B0] space-y-1.5" aria-hidden="true">
                <div className="mx-3 bg-[#1E3A5F] text-[#FDF6E3] border border-[#142842] rounded-md px-3 py-1.5 text-center font-display italic text-xs font-bold shadow-xs">
                  Learn English
                </div>
                <div className="mx-1.5 bg-[#881337] text-[#FDF6E3] border border-[#5F0D26] rounded-md px-3 py-1.5 text-center font-display italic text-xs font-bold shadow-xs">
                  Dream Big
                </div>
                <div className="bg-[#365314] text-[#FDF6E3] border border-[#24380D] rounded-md px-3 py-1.5 text-center font-display italic text-xs font-bold shadow-xs">
                  You Can Do It!
                </div>
              </div>
            </aside>

            {/* Right Column: Vintage 4x8 Advent Door Grid Board */}
            <div className="lg:col-span-8 bg-[#DFCAA6] border-2 border-[#BFA374] rounded-2xl p-3 sm:p-5">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-3.5">
                {doors.map((dayNum) => {
                  const key = makeTestKey(config.id, dayNum);
                  const isChecked = Boolean(checkedMap[key]);
                  const nonce = shuffleMap[key] ?? 0;
                  const scoreInfo = calculateSingleTestScore(
                    config.id,
                    dayNum,
                    userAnswers,
                    shuffleMap
                  );
                  const testTitle = getTestTitle(config.id, dayNum, nonce);
                  const doorVariant = getDoorStyleVariant(dayNum);

                  const isDark =
                    doorVariant === 'suitcase-primary' || doorVariant === 'suitcase-secondary';

                  const cardBg =
                    doorVariant === 'suitcase-primary'
                      ? suitcaseColors.primaryBg
                      : doorVariant === 'suitcase-secondary'
                      ? suitcaseColors.secondaryBg
                      : '#FBF6E8';

                  const borderStyle =
                    doorVariant === 'stamp'
                      ? 'border-2 border-dashed border-[#CBB389]'
                      : doorVariant === 'airmail'
                      ? 'border-2 border-[#991B1B]/50'
                      : 'border-2 border-[#D4AF37]/60';

                  return (
                    <button
                      key={dayNum}
                      type="button"
                      onClick={() => onOpenDoor(config.id, dayNum)}
                      title={`День ${dayNum}: ${testTitle}`}
                      className={`group relative rounded-xl p-3 pt-4 flex flex-col items-center justify-between gap-1.5 min-h-[126px] transition-transform duration-200 hover:-translate-y-0.5 cursor-pointer shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-900 ${borderStyle}`}
                      style={{ backgroundColor: cardBg }}
                    >
                      {/* Suitcase handle & brass corners on dark suitcase doors */}
                      {isDark && (
                        <>
                          <span
                            className="absolute -top-2 left-1/2 -translate-x-1/2 w-8 h-2.5 rounded-t-md border-2 border-[#D4AF37] bg-transparent pointer-events-none"
                            aria-hidden="true"
                          />
                          <span
                            className="absolute top-1 left-1 w-2 h-2 border-t-2 border-l-2 border-[#E7C66B] rounded-tl-xs pointer-events-none"
                            aria-hidden="true"
                          />
                          <span
                            className="absolute top-1 right-1 w-2 h-2 border-t-2 border-r-2 border-[#E7C66B] rounded-tr-xs pointer-events-none"
                            aria-hidden="true"
                          />
                          <span
                            className="absolute bottom-1 left-1 w-2 h-2 border-b-2 border-l-2 border-[#E7C66B] rounded-bl-xs pointer-events-none"
                            aria-hidden="true"
                          />
                          <span
                            className="absolute bottom-1 right-1 w-2 h-2 border-b-2 border-r-2 border-[#E7C66B] rounded-br-xs pointer-events-none"
                            aria-hidden="true"
                          />
                        </>
                      )}

                      {/* Top status badge if checked or in-progress */}
                      {isChecked && (
                        <span
                          className="absolute top-1.5 right-1.5 inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded font-mono text-[10px] font-bold tabular-nums bg-emerald-700 text-white"
                        >
                          <Check className="w-2.5 h-2.5" />
                          {scoreInfo.score}/{scoreInfo.total}
                        </span>
                      )}

                      {!isChecked && scoreInfo.answered > 0 && (
                        <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded font-mono text-[10px] font-bold tabular-nums bg-amber-600 text-white">
                          {scoreInfo.answered}/{scoreInfo.total}
                        </span>
                      )}

                      {/* Door Number */}
                      <span
                        className="font-display text-2xl sm:text-[26px] font-bold leading-none tabular-nums"
                        style={{ color: isDark ? '#FFFDF7' : '#1C1917' }}
                      >
                        {dayNum}
                      </span>

                      {/* Miniature Vintage Illustration */}
                      <div className="my-0.5">
                        <VintageDoorMotif
                          kind={config.id}
                          day={dayNum}
                          isDarkSurface={isDark}
                        />
                      </div>

                      {/* Subtle 1-line test topic */}
                      <span
                        className="text-[10px] font-semibold line-clamp-1 w-full text-center leading-tight opacity-90"
                        style={{ color: isDark ? '#FDE68A' : '#57534E' }}
                      >
                        {testTitle}
                      </span>
                    </button>
                  );
                })}

                {/* Final Row Corner Vignette matching row 8 column 4 of image_68e72c4c.png */}
                <div className="hidden sm:flex rounded-xl border-2 border-dashed border-[#BFA374] bg-[#F5EBD6]/70 p-3 flex-col items-center justify-center text-center gap-1 min-h-[126px]">
                  <span className="font-display italic font-bold text-sm text-stone-800">
                    {stats.completedTests === stats.totalTests
                      ? 'Календар пройдено!'
                      : `Сітка 4 × 8`}
                  </span>
                  <span className="font-mono text-xs font-bold text-stone-700 tabular-nums">
                    {stats.earnedPoints} / {stats.maxPoints}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};
