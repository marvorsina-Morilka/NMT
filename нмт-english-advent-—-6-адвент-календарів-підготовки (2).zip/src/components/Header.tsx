import React from 'react';
import { TaskKind } from '../types/nmt';

export type ActiveRoute = 'overview' | 'calendar' | 'test' | 'summary';

interface HeaderProps {
  activeRoute: ActiveRoute;
  selectedAdvent: TaskKind;
  onNavigateOverview: () => void;
  onNavigateCalendar: (kind: TaskKind) => void;
  onNavigateSummary: () => void;
  onStartRandomTest: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeRoute,
  selectedAdvent,
  onNavigateOverview,
  onNavigateCalendar,
  onNavigateSummary,
  onStartRandomTest,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F4]/95 backdrop-blur-sm border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        <button
          type="button"
          onClick={onNavigateOverview}
          className="font-display text-lg sm:text-xl font-bold tracking-tight text-stone-900 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-800 rounded"
        >
          НМТ English Advent
        </button>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-stone-600">
          <button
            type="button"
            onClick={onNavigateOverview}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeRoute === 'overview'
                ? 'text-stone-950 border-stone-900 font-semibold'
                : 'border-transparent hover:text-stone-950 hover:border-stone-300'
            }`}
          >
            Усі 6 адвентів
          </button>
          <button
            type="button"
            onClick={() => onNavigateCalendar(selectedAdvent)}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeRoute === 'calendar' || activeRoute === 'test'
                ? 'text-stone-950 border-stone-900 font-semibold'
                : 'border-transparent hover:text-stone-950 hover:border-stone-300'
            }`}
          >
            Сітка календаря
          </button>
          <button
            type="button"
            onClick={onNavigateSummary}
            className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
              activeRoute === 'summary'
                ? 'text-stone-950 border-stone-900 font-semibold'
                : 'border-transparent hover:text-stone-950 hover:border-stone-300'
            }`}
          >
            Підсумки
          </button>
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onStartRandomTest}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-stone-50 bg-stone-900 rounded-lg hover:bg-stone-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-800"
          >
            Випадковий тест
          </button>
        </div>
      </div>

      <div className="md:hidden border-t border-stone-200 px-4 py-2 flex items-center justify-around gap-2 bg-[#FAF8F4]">
        <button
          type="button"
          onClick={onNavigateOverview}
          className={`text-xs font-semibold px-2 py-1 whitespace-nowrap shrink-0 ${
            activeRoute === 'overview' ? 'text-stone-950 underline underline-offset-4' : 'text-stone-600'
          }`}
        >
          Адвенти
        </button>
        <button
          type="button"
          onClick={() => onNavigateCalendar(selectedAdvent)}
          className={`text-xs font-semibold px-2 py-1 whitespace-nowrap shrink-0 ${
            activeRoute === 'calendar' || activeRoute === 'test'
              ? 'text-stone-950 underline underline-offset-4'
              : 'text-stone-600'
          }`}
        >
          Календар
        </button>
        <button
          type="button"
          onClick={onNavigateSummary}
          className={`text-xs font-semibold px-2 py-1 whitespace-nowrap shrink-0 ${
            activeRoute === 'summary' ? 'text-stone-950 underline underline-offset-4' : 'text-stone-600'
          }`}
        >
          Підсумки
        </button>
      </div>
    </header>
  );
};
