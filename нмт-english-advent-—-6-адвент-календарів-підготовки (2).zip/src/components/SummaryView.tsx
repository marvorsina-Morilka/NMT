import React, { useState } from 'react';
import { ArrowRight, RotateCcw, Shuffle } from 'lucide-react';
import { ADVENTS_CONFIG } from '../data/adventsMeta';
import { CheckedMap, ShuffleSeedMap, TaskKind, UserAnswersMap } from '../types/nmt';
import {
  calculateAdventStats,
  calculateGlobalStats,
  calculateSingleTestScore,
  makeTestKey,
} from '../utils/nmtHelpers';

interface SummaryViewProps {
  userAnswers: UserAnswersMap;
  checkedMap: CheckedMap;
  shuffleMap: ShuffleSeedMap;
  onOpenDoor: (kind: TaskKind, testId: number) => void;
  onOpenAdvent: (kind: TaskKind) => void;
  onReshuffleAll: () => void;
  onResetAll: () => void;
}

export const SummaryView: React.FC<SummaryViewProps> = ({
  userAnswers,
  checkedMap,
  shuffleMap,
  onOpenDoor,
  onOpenAdvent,
  onReshuffleAll,
  onResetAll,
}) => {
  const globalStats = calculateGlobalStats(userAnswers, checkedMap, shuffleMap);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      <section className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-wider text-stone-500">
            Загальний підсумок підготовки до НМТ
          </p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-stone-950">
            Аналітика по всіх 6 адвентах (186 тестів)
          </h1>
          <p className="text-sm text-stone-600 leading-relaxed">
            Тут зібрано ваші результати за всіма шістьма типами завдань НМТ. Натисніть на будь-яку клітинку тесту, щоб миттєво перейти до нього або переглянути помилки.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onReshuffleAll}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-stone-300 bg-white hover:bg-stone-50 text-stone-800 text-sm font-semibold transition-colors cursor-pointer"
          >
            <Shuffle className="w-4 h-4" />
            <span>Перемішати всі тести</span>
          </button>
          <button
            type="button"
            onClick={() => setConfirmResetOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-800 text-sm font-semibold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Скинути прогрес</span>
          </button>
        </div>
      </section>

      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-stone-200 rounded-xl p-5 space-y-1">
          <span className="text-xs font-semibold text-stone-500">Набрано балів</span>
          <p className="font-mono text-3xl font-bold text-stone-950 tabular-nums">
            {globalStats.earnedPoints}{' '}
            <span className="text-base font-normal text-stone-500">/ {globalStats.maxPoints}</span>
          </p>
        </div>
        <div className="bg-white border border-stone-200 rounded-xl p-5 space-y-1">
          <span className="text-xs font-semibold text-stone-500">Відсоток виконання</span>
          <p className="font-mono text-3xl font-bold text-stone-950 tabular-nums">
            {globalStats.percent}%
          </p>
        </div>
        <div className="bg-white border border-stone-200 rounded-xl p-5 space-y-1">
          <span className="text-xs font-semibold text-stone-500">Завершено тестів</span>
          <p className="font-mono text-3xl font-bold text-stone-950 tabular-nums">
            {globalStats.completedTests}{' '}
            <span className="text-base font-normal text-stone-500">/ {globalStats.totalTests}</span>
          </p>
        </div>
      </section>

      <section className="space-y-6">
        {ADVENTS_CONFIG.map((advent) => {
          const stats = calculateAdventStats(advent.id, userAnswers, checkedMap, shuffleMap);
          const testNumbers = Array.from({ length: advent.totalTests }, (_, i) => i + 1);

          return (
            <div key={advent.id} className="bg-white border border-stone-200 rounded-2xl p-6 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100">
                <div className="space-y-1">
                  <div className="text-xs font-medium text-stone-500 flex flex-wrap items-center gap-2 tabular-nums">
                    <span className="font-bold" style={{ color: advent.accentTextHex }}>
                      Адвент {advent.adventNumber}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{advent.questionRangeLabel}</span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {stats.completedTests} / {stats.totalTests} тестів
                    </span>
                  </div>
                  <h2 className="font-display text-xl font-bold text-stone-950">
                    {advent.themeName} — {advent.ukrainianTitle}
                  </h2>
                </div>

                <div className="flex items-center gap-4 shrink-0">
                  <span className="font-mono text-sm font-bold text-stone-900 tabular-nums">
                    {stats.earnedPoints} / {stats.maxPoints} балів
                  </span>
                  <button
                    type="button"
                    onClick={() => onOpenAdvent(advent.id)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-700 hover:text-stone-950 underline underline-offset-4 cursor-pointer"
                  >
                    <span>До сітки</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-4 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-11 gap-2">
                {testNumbers.map((num) => {
                  const key = makeTestKey(advent.id, num);
                  const isChecked = Boolean(checkedMap[key]);
                  const res = calculateSingleTestScore(advent.id, num, userAnswers, shuffleMap);
                  const isPerfect = isChecked && res.score === res.total;

                  return (
                    <button
                      key={num}
                      type="button"
                      onClick={() => onOpenDoor(advent.id, num)}
                      className={`p-2 rounded-lg border text-center transition-colors cursor-pointer tabular-nums ${
                        isChecked
                          ? isPerfect
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                            : 'bg-amber-50 border-amber-300 text-amber-900'
                          : res.answered > 0
                          ? 'bg-stone-100 border-stone-300 text-stone-800'
                          : 'bg-white border-stone-200 text-stone-600 hover:border-stone-400'
                      }`}
                    >
                      <div className="font-mono text-xs font-bold">Т{num}</div>
                      <div className="font-mono text-[10px] mt-0.5">
                        {isChecked ? `${res.score}/${res.total}` : res.answered > 0 ? `${res.answered}/${res.total}` : '—'}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </section>

      {confirmResetOpen && (
        <div
          className="fixed inset-0 z-50 bg-stone-950/50 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="reset-dialog-title"
        >
          <div className="bg-white border border-stone-200 rounded-2xl max-w-md w-full p-6 space-y-4">
            <h3 id="reset-dialog-title" className="font-display text-xl font-bold text-stone-950">
              Скинути весь прогрес?
            </h3>
            <p className="text-sm text-stone-600 leading-relaxed">
              Усі збережені відповіді та результати перевірки по всіх 186 тестах буде видалено. Цю дію неможливо скасувати.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setConfirmResetOpen(false)}
                className="px-4 py-2 rounded-lg border border-stone-300 text-sm font-semibold text-stone-700 hover:bg-stone-50 cursor-pointer"
              >
                Скасувати
              </button>
              <button
                type="button"
                onClick={() => {
                  onResetAll();
                  setConfirmResetOpen(false);
                }}
                className="px-4 py-2 rounded-lg bg-rose-700 text-white text-sm font-semibold hover:bg-rose-800 cursor-pointer"
              >
                Так, скинути все
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
