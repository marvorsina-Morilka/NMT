import React, { useState } from 'react';
import { ArrowRight, BookOpen } from 'lucide-react';
import { ADVENTS_CONFIG } from '../data/adventsMeta';
import { CheckedMap, ShuffleSeedMap, TaskKind, UserAnswersMap } from '../types/nmt';
import { calculateAdventStats, calculateGlobalStats } from '../utils/nmtHelpers';

interface AdventOverviewProps {
  userAnswers: UserAnswersMap;
  checkedMap: CheckedMap;
  shuffleMap: ShuffleSeedMap;
  onSelectAdvent: (kind: TaskKind) => void;
  onOpenSummary: () => void;
}

export const AdventOverview: React.FC<AdventOverviewProps> = ({
  userAnswers,
  checkedMap,
  shuffleMap,
  onSelectAdvent,
  onOpenSummary,
}) => {
  const globalStats = calculateGlobalStats(userAnswers, checkedMap, shuffleMap);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});
  const [refPosterFailed, setRefPosterFailed] = useState(false);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 space-y-12">
      <section className="bg-[#F5EBD6] border-2 border-[#D4BD94] rounded-2xl p-6 sm:p-8 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        <div className="lg:col-span-7 space-y-5">
          <div className="inline-block bg-[#FAF4E8] border border-[#C9AF82] rounded-xl px-4 py-1.5 text-xs font-bold tracking-wide text-stone-800 uppercase">
            Підготовка до НМТ · 6 адвентів · По 31 віконечку в кожному
          </div>

          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-950 leading-tight [text-wrap:balance]">
            Шість вінтажних English Advent Calendars для НМТ
          </h1>

          <div className="bg-[#FAF4E8] border border-[#D4BD94] rounded-xl p-5 max-w-xl space-y-3">
            <div className="flex items-baseline justify-between gap-4">
              <span className="text-xs font-semibold text-stone-600">Загальний прогрес підготовки</span>
              <span className="font-mono text-sm font-bold text-stone-950 tabular-nums">
                {globalStats.earnedPoints} / {globalStats.maxPoints} балів
              </span>
            </div>
            <div className="w-full h-2.5 bg-[#E6D6B8] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#991B1B] transition-all duration-300"
                style={{ width: `${globalStats.percent}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-xs text-stone-600 tabular-nums">
              <span>
                Виконано тестів: {globalStats.completedTests} з {globalStats.totalTests}
              </span>
              <button
                type="button"
                onClick={onOpenSummary}
                className="font-bold text-stone-900 underline underline-offset-4 hover:text-[#991B1B] cursor-pointer"
              >
                Детальна аналітика
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 flex flex-col items-center">
          <button
            type="button"
            onClick={() => onSelectAdvent(TaskKind.TASK_1_MATCHING_ADS)}
            className="group relative max-w-[320px] w-full rounded-xl overflow-hidden border-2 border-[#C9AF82] bg-[#FAF4E8] shadow-sm hover:border-stone-800 transition-colors cursor-pointer"
          >
            {!refPosterFailed ? (
              <img
                src="/assets/aistudio/image_68e72c4c.png"
                alt="Зразок оформлення English Advent Calendar"
                referrerPolicy="no-referrer"
                onError={() => setRefPosterFailed(true)}
                className="w-full aspect-[2/3] object-cover transition-transform duration-300 group-hover:scale-[1.01]"
              />
            ) : (
              <div className="w-full aspect-[2/3] flex flex-col items-center justify-center p-6 text-center bg-[#FAF4E8]">
                <BookOpen className="w-10 h-10 mb-3 text-stone-700" />
                <span className="font-display font-bold text-xl text-stone-900">
                  English Advent Calendar
                </span>
              </div>
            )}
            <div className="px-4 py-2.5 bg-[#FAF4E8] border-t border-[#D4BD94] flex items-center justify-between text-xs font-semibold text-stone-800">
              <span>Постер-зразок (сітка 4 × 8)</span>
              <span className="inline-flex items-center gap-1 text-[#991B1B] font-bold">
                Відкрити <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </button>
        </div>
      </section>

      <section aria-label="Шість адвент-календарів" className="space-y-6">
        <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-stone-200 pb-3">
          <h2 className="font-display text-2xl font-bold text-stone-950">
            Оберіть адвент-календар (Завдання 1–6)
          </h2>
          <p className="text-xs text-stone-500 tabular-nums">
            Кожен календар має власну вінтажну тему та сітку 4 × 8
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {ADVENTS_CONFIG.map((advent) => {
            const stats = calculateAdventStats(advent.id, userAnswers, checkedMap, shuffleMap);
            const imgFailed = failedImages[advent.id];

            return (
              <article
                key={advent.id}
                className="group bg-[#FAF4E8] border-2 border-[#D8C49E] rounded-2xl overflow-hidden flex flex-col transition-colors hover:border-stone-700"
              >
                <div className="px-4 pt-4 pb-3 bg-[#F3E6CC] border-b border-[#D8C49E] text-center">
                  <div className="bg-[#FFFDF7] border border-[#C9AF82] rounded-xl py-2 px-3">
                    <div className="font-display italic font-bold text-lg text-stone-900 leading-tight">
                      English Advent Calendar
                    </div>
                    <div className="text-[11px] font-semibold text-stone-600 mt-0.5 tabular-nums">
                      Адвент {advent.adventNumber} · {advent.questionRangeLabel} · {advent.totalTests} віконець
                    </div>
                  </div>
                </div>

                <div className="aspect-[3/4] w-full bg-stone-100 relative overflow-hidden border-b border-[#D8C49E]">
                  {!imgFailed ? (
                    <img
                      src={advent.coverImage}
                      alt={advent.themeName}
                      referrerPolicy="no-referrer"
                      onError={() => setFailedImages((prev) => ({ ...prev, [advent.id]: true }))}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                    />
                  ) : (
                    <div
                      className="w-full h-full flex flex-col items-center justify-center p-6 text-center"
                      style={{ backgroundColor: advent.accentSoftHex }}
                    >
                      <BookOpen className="w-8 h-8 mb-2" style={{ color: advent.accentTextHex }} />
                      <span className="font-display font-bold text-base text-stone-900">
                        {advent.themeName}
                      </span>
                    </div>
                  )}
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                  <div className="space-y-2">
                    <h3 className="font-display text-xl font-bold text-stone-950 leading-snug">
                      {advent.themeName}
                    </h3>
                    <p className="text-sm font-semibold" style={{ color: advent.accentTextHex }}>
                      {advent.ukrainianTitle}
                    </p>
                    <p className="text-sm text-stone-700 leading-relaxed">{advent.description}</p>
                  </div>

                  <div className="space-y-4 pt-3 border-t border-[#E2D1B0]">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs text-stone-700 tabular-nums">
                        <span>
                          Відкрито {stats.completedTests} / {stats.totalTests}
                        </span>
                        <span className="font-mono font-bold text-stone-950">
                          {stats.earnedPoints} / {stats.maxPoints} балів
                        </span>
                      </div>
                      <div className="w-full h-2 bg-[#E6D6B8] rounded-full overflow-hidden">
                        <div
                          className="h-full transition-all duration-300"
                          style={{
                            width: `${stats.percent}%`,
                            backgroundColor: advent.accentHex,
                          }}
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onSelectAdvent(advent.id)}
                      className="w-full py-2.5 px-4 rounded-lg text-sm font-semibold text-white flex items-center justify-center gap-2 transition-opacity hover:opacity-90 cursor-pointer whitespace-nowrap"
                      style={{ backgroundColor: advent.accentHex }}
                    >
                      <span>Відкрити адвент</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </section>
    </div>
  );
};
