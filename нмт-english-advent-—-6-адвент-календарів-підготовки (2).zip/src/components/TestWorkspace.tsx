import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Eye,
  EyeOff,
  RotateCcw,
  Shuffle,
  X,
} from 'lucide-react';
import { getAdventConfig } from '../data/adventsMeta';
import { getTask1Test } from '../data/task1Data';
import { getTask2Test } from '../data/task2Data';
import { getTask3Test } from '../data/task3Data';
import { getTask4Test } from '../data/task4Data';
import { getTask5Test } from '../data/task5Data';
import { getTask6Test } from '../data/task6Data';
import {
  LetterOption,
  McqQuestion,
  TaskKind,
} from '../types/nmt';
import { calculateSingleTestScore, makeTestKey } from '../utils/nmtHelpers';

interface TestWorkspaceProps {
  adventKind: TaskKind;
  testId: number;
  answers: Record<number, string>;
  isChecked: boolean;
  shuffleNonce: number;
  onSelectAnswer: (qNum: number, letter: string) => void;
  onCheckTest: () => void;
  onRevealAnswers: (correctMap: Record<number, string>) => void;
  onResetTest: () => void;
  onReshuffleTest: () => void;
  onNavigateDoor: (nextId: number) => void;
  onBackToGrid: () => void;
}

export const TestWorkspace: React.FC<TestWorkspaceProps> = ({
  adventKind,
  testId,
  answers,
  isChecked,
  shuffleNonce,
  onSelectAnswer,
  onCheckTest,
  onRevealAnswers,
  onResetTest,
  onReshuffleTest,
  onNavigateDoor,
  onBackToGrid,
}) => {
  const config = getAdventConfig(adventKind);
  const [showKeys, setShowKeys] = useState(false);

  useEffect(() => {
    setShowKeys(false);
  }, [adventKind, testId]);

  const testKey = makeTestKey(adventKind, testId);
  const scoreSummary = calculateSingleTestScore(
    adventKind,
    testId,
    { [testKey]: answers },
    { [testKey]: shuffleNonce }
  );

  let currentTitle = '';
  let currentCorrectMap: Record<number, string> = {};

  const renderTaskBody = () => {
    if (adventKind === TaskKind.TASK_1_MATCHING_ADS) {
      const test = getTask1Test(testId, shuffleNonce);
      currentTitle = test.title;
      currentCorrectMap = test.keys;

      return (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 space-y-4">
            <h2 className="font-display text-lg font-bold text-stone-900">
              Оголошення (1–5)
            </h2>
            <div className="space-y-4">
              {test.texts.map((ad) => (
                <article
                  key={ad.id}
                  className="bg-white border border-stone-200 rounded-xl p-5 space-y-2"
                >
                  <div className="flex items-baseline gap-2.5">
                    <span
                      className="font-mono text-sm font-bold tabular-nums"
                      style={{ color: config.accentTextHex }}
                    >
                      {ad.id}.
                    </span>
                    <h3 className="font-display text-base font-bold text-stone-950">
                      {ad.title}
                    </h3>
                  </div>
                  <p className="text-sm text-stone-700 leading-relaxed">{ad.text}</p>
                </article>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 bg-white border border-stone-200 rounded-xl p-5 sm:p-6 space-y-6">
            <div className="space-y-1 border-b border-stone-100 pb-3">
              <h2 className="font-display text-lg font-bold text-stone-950">
                Варіанти (A–H)
              </h2>
              <p className="text-xs text-stone-500">
                This advertisement is for people who want to… (3 зайві варіанти)
              </p>
            </div>

            <div className="space-y-2">
              {test.options.map((opt) => (
                <div
                  key={opt.letter}
                  className="flex items-start gap-2.5 p-2.5 rounded-lg bg-stone-50 border border-stone-200/80 text-xs sm:text-sm text-stone-800"
                >
                  <span
                    className="font-mono font-bold text-xs w-6 h-6 rounded flex items-center justify-center shrink-0"
                    style={{ backgroundColor: config.accentSoftHex, color: config.accentTextHex }}
                  >
                    {opt.letter}
                  </span>
                  <span className="leading-snug pt-0.5">{opt.text}</span>
                </div>
              ))}
            </div>

            <div className="space-y-3 pt-4 border-t border-stone-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                Встановіть відповідності (1–5)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2.5">
                {test.texts.map((ad) =>
                  renderMatchingRow(ad.id, `Оголошення ${ad.id}`, test.options, test.keys[ad.id])
                )}
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (adventKind === TaskKind.TASK_2_READING_MCQ) {
      const test = getTask2Test(testId, shuffleNonce);
      currentTitle = test.title;
      currentCorrectMap = Object.fromEntries(test.questions.map((q) => [q.num, q.correct]));

      return (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 bg-white border border-stone-200 rounded-xl p-6 sm:p-8 space-y-5">
            <div className="border-b border-stone-100 pb-4 space-y-1">
              <span className="text-xs font-semibold uppercase tracking-wider text-stone-500">
                Текст для читання
              </span>
              <h2 className="font-display text-xl sm:text-2xl font-bold text-stone-950">
                {test.title}
              </h2>
            </div>
            <div className="space-y-4 text-[15px] sm:text-base text-stone-700 leading-relaxed">
              {test.paragraphs.map((p, idx) => (
                <p key={idx}>{p}</p>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 space-y-4">
            {test.questions.map((q) => renderMcqBlock(q))}
          </div>
        </div>
      );
    }

    if (adventKind === TaskKind.TASK_3_MATCHING_TEXTS) {
      const test = getTask3Test(testId, shuffleNonce);
      currentTitle = test.title;
      currentCorrectMap = test.correct;

      return (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-baseline justify-between">
              <h2 className="font-display text-lg font-bold text-stone-950">{test.title}</h2>
              <span className="text-xs text-stone-500">Тексти 11–16</span>
            </div>
            <div className="space-y-4">
              {test.items.map((item) => (
                <article
                  key={item.num}
                  className="bg-white border border-stone-200 rounded-xl p-5 space-y-2"
                >
                  <div className="flex items-baseline gap-2.5">
                    <span
                      className="font-mono text-sm font-bold tabular-nums"
                      style={{ color: config.accentTextHex }}
                    >
                      {item.num}.
                    </span>
                    <h3 className="font-display text-base font-bold text-stone-950">
                      {item.name}
                    </h3>
                  </div>
                  <p className="text-sm text-stone-700 leading-relaxed">{item.text}</p>
                </article>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 bg-white border border-stone-200 rounded-xl p-5 sm:p-6 space-y-6">
            <div className="space-y-1 border-b border-stone-100 pb-3">
              <h2 className="font-display text-lg font-bold text-stone-950">
                Твердження (A–H)
              </h2>
              <p className="text-xs text-stone-500">
                Доберіть відповідне твердження до кожного опису (2 зайві)
              </p>
            </div>

            <div className="space-y-2">
              {test.choices.map((ch) => (
                <div
                  key={ch.letter}
                  className="flex items-start gap-2.5 p-2.5 rounded-lg bg-stone-50 border border-stone-200/80 text-xs sm:text-sm text-stone-800"
                >
                  <span
                    className="font-mono font-bold text-xs w-6 h-6 rounded flex items-center justify-center shrink-0"
                    style={{ backgroundColor: config.accentSoftHex, color: config.accentTextHex }}
                  >
                    {ch.letter}
                  </span>
                  <span className="leading-snug pt-0.5">{ch.text}</span>
                </div>
              ))}
            </div>

            <div className="space-y-3 pt-4 border-t border-stone-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                Встановіть відповідності (11–16)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2.5">
                {test.items.map((item) =>
                  renderMatchingRow(
                    item.num,
                    `Питання ${item.num}`,
                    test.choices,
                    test.correct[item.num]
                  )
                )}
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (adventKind === TaskKind.TASK_4_GAP_FILL_CLAUSES) {
      const test = getTask4Test(testId, shuffleNonce);
      currentTitle = test.title;
      currentCorrectMap = test.correct;
      const gapNumbers = [17, 18, 19, 20, 21, 22];

      return (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 bg-white border border-stone-200 rounded-xl p-6 sm:p-8 space-y-5">
            <div className="border-b border-stone-100 pb-4 space-y-1">
              <span className="text-xs font-semibold uppercase tracking-wider text-stone-500">
                Заповнення пропусків у тексті (17–22)
              </span>
              <h2 className="font-display text-xl sm:text-2xl font-bold text-stone-950">
                {test.title}
              </h2>
            </div>

            <div className="space-y-4 text-[15px] sm:text-base text-stone-700 leading-relaxed">
              {test.paragraphs.map((p, idx) => (
                <p key={idx}>{renderTextWithGaps(p, gapNumbers, test.correct)}</p>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 bg-white border border-stone-200 rounded-xl p-5 sm:p-6 space-y-6">
            <div className="space-y-1 border-b border-stone-100 pb-3">
              <h2 className="font-display text-lg font-bold text-stone-950">
                Фрази для пропусків (A–H)
              </h2>
              <p className="text-xs text-stone-500">2 варіанти є зайвими</p>
            </div>

            <div className="space-y-2">
              {test.choices.map((ch) => (
                <div
                  key={ch.letter}
                  className="flex items-start gap-2.5 p-2.5 rounded-lg bg-stone-50 border border-stone-200/80 text-xs sm:text-sm text-stone-800"
                >
                  <span
                    className="font-mono font-bold text-xs w-6 h-6 rounded flex items-center justify-center shrink-0"
                    style={{ backgroundColor: config.accentSoftHex, color: config.accentTextHex }}
                  >
                    {ch.letter}
                  </span>
                  <span className="leading-snug pt-0.5">{ch.text}</span>
                </div>
              ))}
            </div>

            <div className="space-y-3 pt-4 border-t border-stone-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                Оберіть варіант для кожного пропуску
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2.5">
                {gapNumbers.map((gNum) =>
                  renderMatchingRow(gNum, `Пропуск (${gNum})`, test.choices, test.correct[gNum])
                )}
              </div>
            </div>
          </div>
        </div>
      );
    }

    // Task 5 or Task 6 (Use of English)
    const test =
      adventKind === TaskKind.TASK_5_USE_OF_ENGLISH_VOCAB
        ? getTask5Test(testId, shuffleNonce)
        : getTask6Test(testId, shuffleNonce);
    currentTitle = test.title;
    currentCorrectMap = Object.fromEntries(test.questions.map((q) => [q.num, q.correct]));

    const optionWordByQ: Record<number, Record<string, string>> = {};
    for (const q of test.questions) {
      optionWordByQ[q.num] = Object.fromEntries(q.options.map((o) => [o.letter, o.text]));
    }

    return (
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 bg-white border border-stone-200 rounded-xl p-6 sm:p-8 space-y-5">
          <div className="border-b border-stone-100 pb-4 space-y-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-stone-500">
              {config.taskFormatLabel}
            </span>
            <h2 className="font-display text-xl sm:text-2xl font-bold text-stone-950">
              {test.title}
            </h2>
          </div>

          <div className="text-[15px] sm:text-base text-stone-700 leading-loose">
            {renderTextWithGaps(
              test.text,
              test.questions.map((q) => q.num),
              currentCorrectMap,
              optionWordByQ
            )}
          </div>
        </div>

        <div className="lg:col-span-5 space-y-4">
          {test.questions.map((q) => renderMcqBlock(q))}
        </div>
      </div>
    );
  };

  function renderTextWithGaps(
    rawText: string,
    gapNums: number[],
    correctMap: Record<number, string>,
    wordLookup?: Record<number, Record<string, string>>
  ) {
    const regex = /\((\d+)\)\s*_{3,}/g;
    const parts: React.ReactNode[] = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = regex.exec(rawText)) !== null) {
      const gapNum = Number(match[1]);
      if (match.index > lastIndex) {
        parts.push(rawText.slice(lastIndex, match.index));
      }

      if (gapNums.includes(gapNum)) {
        const userLetter = answers[gapNum];
        const correctLetter = correctMap[gapNum];
        const userWord = userLetter && wordLookup?.[gapNum]?.[userLetter];
        const correctWord = correctLetter && wordLookup?.[gapNum]?.[correctLetter];

        let badgeClass = 'bg-stone-100 text-stone-800 border-stone-300';
        let label = `(${gapNum}) ___`;

        if (isChecked) {
          if (userLetter === correctLetter) {
            badgeClass = 'bg-emerald-50 text-emerald-900 border-emerald-400';
            label = userWord ? `(${gapNum}) ${userWord} ✓` : `(${gapNum}) ${userLetter} ✓`;
          } else if (userLetter) {
            badgeClass = 'bg-rose-50 text-rose-900 border-rose-400';
            label = userWord
              ? `(${gapNum}) ${userWord} ✗ → ${correctWord ?? correctLetter}`
              : `(${gapNum}) ${userLetter} ✗ → ${correctLetter}`;
          } else {
            badgeClass = 'bg-amber-50 text-amber-900 border-amber-400';
            label = correctWord
              ? `(${gapNum}) ${correctWord}`
              : `(${gapNum}) Ключ: ${correctLetter}`;
          }
        } else if (userLetter) {
          badgeClass = 'bg-stone-900 text-white border-stone-900';
          label = userWord ? `(${gapNum}) ${userWord}` : `(${gapNum}) ${userLetter}`;
        } else if (showKeys) {
          badgeClass = 'bg-amber-50 text-amber-900 border-amber-300';
          label = correctWord ? `(${gapNum}) ${correctWord}` : `(${gapNum}) ${correctLetter}`;
        }

        parts.push(
          <span
            key={`${gapNum}-${match.index}`}
            className={`inline-flex items-center px-2 py-0.5 mx-1 rounded border font-mono text-xs sm:text-sm font-semibold tabular-nums ${badgeClass}`}
          >
            {label}
          </span>
        );
      } else {
        parts.push(match[0]);
      }

      lastIndex = regex.lastIndex;
    }

    if (lastIndex < rawText.length) {
      parts.push(rawText.slice(lastIndex));
    }

    return parts;
  }

  function renderMatchingRow(
    qNum: number,
    label: string,
    choices: LetterOption[],
    correctLetter: string
  ) {
    const userVal = answers[qNum] ?? '';
    const isCorrect = isChecked && userVal === correctLetter;
    const isWrong = isChecked && userVal !== '' && userVal !== correctLetter;
    const isMissed = isChecked && userVal === '';

    return (
      <div
        key={qNum}
        className={`p-3 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${
          isCorrect
            ? 'bg-emerald-50/70 border-emerald-300'
            : isWrong
            ? 'bg-rose-50/70 border-rose-300'
            : isMissed
            ? 'bg-amber-50/70 border-amber-300'
            : 'bg-stone-50/60 border-stone-200'
        }`}
      >
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs sm:text-sm font-bold text-stone-900 tabular-nums">
            {label}
          </span>

          {isChecked && (
            <span className="inline-flex items-center gap-1 text-xs font-bold">
              {isCorrect && (
                <span className="text-emerald-800 inline-flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Вірно
                </span>
              )}
              {isWrong && (
                <span className="text-rose-800 inline-flex items-center gap-1">
                  <X className="w-3.5 h-3.5" /> Ключ: {correctLetter}
                </span>
              )}
              {isMissed && (
                <span className="text-amber-800">Пропущено · Ключ: {correctLetter}</span>
              )}
            </span>
          )}

          {!isChecked && showKeys && (
            <span className="font-mono text-xs font-bold text-stone-700">
              Ключ: {correctLetter}
            </span>
          )}
        </div>

        <select
          aria-label={label}
          value={userVal}
          disabled={isChecked}
          onChange={(e) => onSelectAnswer(qNum, e.target.value)}
          className="bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs sm:text-sm font-semibold text-stone-900 cursor-pointer disabled:opacity-80 disabled:cursor-default focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-800"
        >
          <option value="">Оберіть літеру</option>
          {choices.map((ch) => (
            <option key={ch.letter} value={ch.letter}>
              {ch.letter}
            </option>
          ))}
        </select>
      </div>
    );
  }

  function renderMcqBlock(q: McqQuestion) {
    const userVal = answers[q.num];
    const isCorrect = isChecked && userVal === q.correct;
    const isWrong = isChecked && userVal && userVal !== q.correct;
    const isMissed = isChecked && !userVal;

    return (
      <div
        key={q.num}
        className="bg-white border border-stone-200 rounded-xl p-5 space-y-3.5"
      >
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h3 className="text-sm sm:text-base font-bold text-stone-950 leading-snug">
            <span className="font-mono mr-1.5 tabular-nums" style={{ color: config.accentTextHex }}>
              {q.num}.
            </span>
            {q.text ?? `Оберіть правильний варіант для пропуску (${q.num})`}
          </h3>

          {isChecked && (
            <span className="text-xs font-bold inline-flex items-center gap-1 shrink-0">
              {isCorrect && (
                <span className="text-emerald-800 inline-flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Вірно
                </span>
              )}
              {isWrong && (
                <span className="text-rose-800 inline-flex items-center gap-1">
                  <X className="w-3.5 h-3.5" /> Помилка (Ключ: {q.correct})
                </span>
              )}
              {isMissed && (
                <span className="text-amber-800">Пропущено (Ключ: {q.correct})</span>
              )}
            </span>
          )}

          {!isChecked && showKeys && (
            <span className="font-mono text-xs font-bold text-stone-700 shrink-0">
              Ключ: {q.correct}
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 gap-2">
          {q.options.map((opt) => {
            const isSelected = userVal === opt.letter;
            const isOptionCorrect = isChecked && opt.letter === q.correct;
            const isOptionWrong = isChecked && isSelected && opt.letter !== q.correct;

            let btnStyle =
              'bg-stone-50 border-stone-200 text-stone-800 hover:bg-stone-100 hover:border-stone-300';
            let letterBg = '#E7E5E4';
            let letterColor = '#1C1917';

            if (isOptionCorrect) {
              btnStyle = 'bg-emerald-50 border-emerald-500 text-emerald-950 font-semibold';
              letterBg = '#059669';
              letterColor = '#FFFFFF';
            } else if (isOptionWrong) {
              btnStyle = 'bg-rose-50 border-rose-500 text-rose-950 font-semibold';
              letterBg = '#DC2626';
              letterColor = '#FFFFFF';
            } else if (isSelected) {
              btnStyle = 'bg-stone-900 border-stone-900 text-white font-semibold';
              letterBg = '#FFFFFF';
              letterColor = '#1C1917';
            }

            return (
              <button
                key={opt.letter}
                type="button"
                disabled={isChecked}
                onClick={() => onSelectAnswer(q.num, opt.letter)}
                className={`w-full text-left px-3.5 py-2.5 rounded-lg border text-xs sm:text-sm flex items-center gap-3 transition-colors cursor-pointer disabled:cursor-default focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-800 ${btnStyle}`}
              >
                <span
                  className="font-mono text-xs font-bold w-6 h-6 rounded flex items-center justify-center shrink-0"
                  style={{ backgroundColor: letterBg, color: letterColor }}
                >
                  {opt.letter}
                </span>
                <span className="flex-1 leading-snug">{opt.text}</span>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  // Evaluate body once so currentTitle and currentCorrectMap are populated
  const workspaceContent = renderTaskBody();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <button
          type="button"
          onClick={onBackToGrid}
          className="inline-flex items-center gap-2 text-sm font-semibold text-stone-600 hover:text-stone-950 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Назад до сітки 4 × 8</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={testId <= 1}
            onClick={() => {
              setShowKeys(false);
              onNavigateDoor(testId - 1);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-300 bg-white text-xs sm:text-sm font-semibold text-stone-700 hover:bg-stone-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>День {testId > 1 ? testId - 1 : 1}</span>
          </button>
          <button
            type="button"
            disabled={testId >= config.totalTests}
            onClick={() => {
              setShowKeys(false);
              onNavigateDoor(testId + 1);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-300 bg-white text-xs sm:text-sm font-semibold text-stone-700 hover:bg-stone-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            <span>День {testId < config.totalTests ? testId + 1 : config.totalTests}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <section className="bg-white border border-stone-200 rounded-2xl p-5 sm:p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs font-medium text-stone-500 flex flex-wrap items-center gap-2 tabular-nums">
            <span className="font-bold" style={{ color: config.accentTextHex }}>
              Адвент {config.adventNumber} · {config.themeName}
            </span>
            <span aria-hidden="true">·</span>
            <span>
              Віконечко {testId} з {config.totalTests}
            </span>
            <span aria-hidden="true">·</span>
            <span>{config.questionRangeLabel}</span>
          </div>
          <h1 className="font-display text-xl sm:text-2xl font-bold text-stone-950">
            {currentTitle}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          {isChecked ? (
            <div className="px-4 py-2 rounded-lg bg-stone-100 border border-stone-200 font-mono text-sm font-bold text-stone-900 tabular-nums">
              Результат: {scoreSummary.score} / {scoreSummary.total} балів
            </div>
          ) : (
            <div className="text-xs font-semibold text-stone-500 tabular-nums">
              Заповнено: {scoreSummary.answered} / {scoreSummary.total}
            </div>
          )}
        </div>
      </section>

      {workspaceContent}

      <section className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onCheckTest}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold text-white transition-opacity hover:opacity-90 cursor-pointer"
            style={{ backgroundColor: config.accentHex }}
          >
            <Check className="w-4 h-4" />
            <span>Перевірити</span>
          </button>

          <button
            type="button"
            onClick={() => setShowKeys((prev) => !prev)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-stone-300 bg-white hover:bg-stone-50 text-stone-800 text-sm font-semibold cursor-pointer"
          >
            {showKeys ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            <span>{showKeys ? 'Сховати ключі' : 'Підказка'}</span>
          </button>

          <button
            type="button"
            onClick={() => onRevealAnswers(currentCorrectMap)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-stone-300 bg-white hover:bg-stone-50 text-stone-800 text-sm font-semibold cursor-pointer"
          >
            <span>Показати відповіді</span>
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => {
              setShowKeys(false);
              onReshuffleTest();
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-stone-300 bg-white hover:bg-stone-50 text-stone-800 text-sm font-semibold cursor-pointer"
          >
            <Shuffle className="w-4 h-4" />
            <span>Перемішати варіанти</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setShowKeys(false);
              onResetTest();
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-stone-300 bg-white hover:bg-stone-50 text-stone-700 text-sm font-semibold cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Очистити</span>
          </button>
        </div>
      </section>
    </div>
  );
};
