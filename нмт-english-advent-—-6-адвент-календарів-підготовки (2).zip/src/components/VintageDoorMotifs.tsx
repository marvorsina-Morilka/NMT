import React from 'react';
import { TaskKind } from '../types/nmt';

interface MotifProps {
  kind: TaskKind;
  day: number;
  isDarkSurface: boolean;
}

export const VintageDoorMotif: React.FC<MotifProps> = ({ kind, day, isDarkSurface }) => {
  const stroke = isDarkSurface ? '#FDF6E3' : '#292524';
  const accent = isDarkSurface ? '#FDE68A' : '#B45309';
  const secondary = isDarkSurface ? '#A7F3D0' : '#0F766E';
  const rose = isDarkSurface ? '#FECDD3' : '#BE123C';

  const variant = (day - 1) % 6;

  if (kind === TaskKind.TASK_1_MATCHING_ADS) {
    // Travel motifs inspired directly by the reference poster: crown, bus, plane, rose, ship, teacup
    switch (variant) {
      case 0: // Crown
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path
              d="M8 24L6 10L15 16L24 7L33 16L42 10L40 24H8Z"
              stroke={accent}
              strokeWidth="2"
              fill={isDarkSurface ? 'rgba(253,230,138,0.2)' : 'rgba(180,83,9,0.15)'}
              strokeLinejoin="round"
            />
            <rect x="8" y="25" width="32" height="3" rx="1" fill={accent} />
            <circle cx="24" cy="5.5" r="1.8" fill={accent} />
          </svg>
        );
      case 1: // Vintage Double-Decker Bus
        return (
          <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
            <rect x="7" y="6" width="34" height="19" rx="3" fill={rose} stroke={stroke} strokeWidth="1.5" />
            <line x1="7" y1="15.5" x2="41" y2="15.5" stroke={stroke} strokeWidth="1.5" />
            <rect x="11" y="9" width="6" height="4" rx="0.8" fill="#FEF3C7" />
            <rect x="20" y="9" width="7" height="4" rx="0.8" fill="#FEF3C7" />
            <rect x="30" y="9" width="7" height="4" rx="0.8" fill="#FEF3C7" />
            <rect x="11" y="18" width="7" height="4" rx="0.8" fill="#FEF3C7" />
            <rect x="21" y="18" width="7" height="4" rx="0.8" fill="#FEF3C7" />
            <circle cx="14" cy="26" r="3" fill={stroke} />
            <circle cx="34" cy="26" r="3" fill={stroke} />
          </svg>
        );
      case 2: // Vintage Airplane
        return (
          <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
            <path
              d="M6 19L19 15L27 6L31 7L26 15L38 13L42 10L43 13L39 17L42 20L38 20L34 18L23 20L19 27L16 26L18 19L8 21L6 19Z"
              fill={secondary}
              stroke={stroke}
              strokeWidth="1.3"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 3: // Botanical Rose
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M24 28V16" stroke={secondary} strokeWidth="2" strokeLinecap="round" />
            <path d="M24 23C19 22 17 19 18 17C20 17 22 19 24 23Z" fill={secondary} />
            <path d="M24 21C29 20 31 17 30 15C28 15 26 17 24 21Z" fill={secondary} />
            <circle cx="24" cy="11" r="6" fill={rose} stroke={stroke} strokeWidth="1.2" />
            <path d="M21 10C22 8 26 8 27 11C26 13 22 13 21 10Z" stroke="#FFF1F2" strokeWidth="1.2" />
          </svg>
        );
      case 4: // Tall Ship / Sailboat
        return (
          <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
            <path d="M10 22H38L34 27H14L10 22Z" fill={stroke} />
            <path d="M24 5V21" stroke={stroke} strokeWidth="1.6" />
            <path d="M24 6L35 19H24V6Z" fill={accent} stroke={stroke} strokeWidth="1.2" />
            <path d="M22 9L13 19H22V9Z" fill={isDarkSurface ? '#E7E5E4' : '#FFFFFF'} stroke={stroke} strokeWidth="1.2" />
          </svg>
        );
      default: // Porcelain Teacup
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M13 13H33C33 20 29 24 23 24C17 24 13 20 13 13Z" fill={isDarkSurface ? '#FEF3C7' : '#FFFFFF'} stroke={stroke} strokeWidth="1.5" />
            <path d="M33 14.5H35.5C37 14.5 38 15.5 38 17C38 18.5 37 19.5 35.5 19.5H32" stroke={stroke} strokeWidth="1.5" />
            <ellipse cx="23" cy="26.5" rx="13" ry="2" fill={accent} />
          </svg>
        );
    }
  }

  if (kind === TaskKind.TASK_2_READING_MCQ) {
    // Coffee shop motifs: espresso cup, croissant, coffee pot, coffee beans, milkshake, pastry
    switch (variant) {
      case 0:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M14 13H32C32 20 28 24 23 24C18 24 14 20 14 13Z" fill={accent} stroke={stroke} strokeWidth="1.5" />
            <path d="M32 14.5H35C36.5 14.5 37.5 15.8 37.5 17C37.5 18.2 36.5 19.5 35 19.5H31.5" stroke={stroke} strokeWidth="1.5" />
            <path d="M19 9C19 7 21 7 21 5M24 9C24 7 26 7 26 5" stroke={stroke} strokeWidth="1.4" strokeLinecap="round" />
            <line x1="12" y1="26.5" x2="34" y2="26.5" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        );
      case 1:
        return (
          <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
            <path
              d="M9 21C11 13 17 9 24 9C31 9 37 13 39 21C35 23 30 22 24 22C18 22 13 23 9 21Z"
              fill={accent}
              stroke={stroke}
              strokeWidth="1.5"
            />
            <path d="M19 10L17 21M29 10L31 21" stroke={stroke} strokeWidth="1.3" />
          </svg>
        );
      case 2:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <ellipse cx="18" cy="16" rx="5.5" ry="7.5" transform="rotate(-18 18 16)" fill={accent} stroke={stroke} strokeWidth="1.4" />
            <ellipse cx="30" cy="17" rx="5.5" ry="7.5" transform="rotate(18 30 17)" fill={accent} stroke={stroke} strokeWidth="1.4" />
            <path d="M17 10C18 14 18 18 19 22" stroke={stroke} strokeWidth="1.3" />
            <path d="M31 11C30 15 30 19 29 23" stroke={stroke} strokeWidth="1.3" />
          </svg>
        );
      case 3:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M17 10H31L29 27H19L17 10Z" fill={rose} stroke={stroke} strokeWidth="1.5" />
            <path d="M16 10C16 6.5 20 5 24 5C28 5 32 6.5 32 10" fill={isDarkSurface ? '#FFFDF7' : '#FEF3C7'} stroke={stroke} strokeWidth="1.4" />
            <line x1="27" y1="3" x2="25" y2="10" stroke={stroke} strokeWidth="1.5" />
          </svg>
        );
      case 4:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <circle cx="24" cy="17" r="9" fill={rose} stroke={stroke} strokeWidth="1.5" />
            <circle cx="24" cy="17" r="3.2" fill={isDarkSurface ? '#1C1917' : '#FAF3E3'} stroke={stroke} strokeWidth="1.2" />
            <path d="M18 13L20 11M28 12L30 14M26 22L28 21" stroke="#FEF3C7" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        );
      default:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M16 11H32L34 26H14L16 11Z" fill={accent} stroke={stroke} strokeWidth="1.5" />
            <path d="M15 11C15 8 19 7 24 7C29 7 33 8 33 11" stroke={stroke} strokeWidth="1.5" />
            <path d="M32 14H36V21H33" stroke={stroke} strokeWidth="1.5" />
          </svg>
        );
    }
  }

  if (kind === TaskKind.TASK_3_MATCHING_TEXTS) {
    // Botanical motifs: rose, tulip, watering can, butterfly, potted herb, garden arch
    switch (variant) {
      case 0:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M24 28V15" stroke={secondary} strokeWidth="2" strokeLinecap="round" />
            <circle cx="24" cy="11" r="6" fill={rose} stroke={stroke} strokeWidth="1.3" />
            <path d="M24 22L18 19M24 20L30 17" stroke={secondary} strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        );
      case 1:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M17 11L20 18H28L31 11L27 14L24 8L21 14L17 11Z" fill={rose} stroke={stroke} strokeWidth="1.3" strokeLinejoin="round" />
            <path d="M24 18V28" stroke={secondary} strokeWidth="2" />
          </svg>
        );
      case 2:
        return (
          <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
            <rect x="17" y="13" width="15" height="12" rx="2" fill={accent} stroke={stroke} strokeWidth="1.4" />
            <path d="M17 19L9 13" stroke={stroke} strokeWidth="2" strokeLinecap="round" />
            <path d="M32 14C36 14 37 17 37 19C37 21 35 23 32 23" stroke={stroke} strokeWidth="1.6" />
            <path d="M20 13C20 9 29 9 29 13" stroke={stroke} strokeWidth="1.5" />
          </svg>
        );
      case 3:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M24 11V24" stroke={stroke} strokeWidth="2" strokeLinecap="round" />
            <ellipse cx="17" cy="14" rx="6" ry="5" fill={accent} stroke={stroke} strokeWidth="1.2" />
            <ellipse cx="31" cy="14" rx="6" ry="5" fill={accent} stroke={stroke} strokeWidth="1.2" />
            <ellipse cx="18" cy="21" rx="4.5" ry="3.5" fill={rose} stroke={stroke} strokeWidth="1.2" />
            <ellipse cx="30" cy="21" rx="4.5" ry="3.5" fill={rose} stroke={stroke} strokeWidth="1.2" />
          </svg>
        );
      case 4:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M17 18H31L29 28H19L17 18Z" fill={accent} stroke={stroke} strokeWidth="1.4" />
            <path d="M24 18V9M24 14L18 10M24 13L30 9" stroke={secondary} strokeWidth="2" strokeLinecap="round" />
          </svg>
        );
      default:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M14 27V15C14 9.5 18.5 6 24 6C29.5 6 34 9.5 34 15V27" stroke={stroke} strokeWidth="1.8" />
            <line x1="19" y1="12" x2="19" y2="27" stroke={stroke} strokeWidth="1.3" />
            <line x1="24" y1="7" x2="24" y2="27" stroke={stroke} strokeWidth="1.3" />
            <line x1="29" y1="12" x2="29" y2="27" stroke={stroke} strokeWidth="1.3" />
          </svg>
        );
    }
  }

  if (kind === TaskKind.TASK_4_GAP_FILL_CLAUSES) {
    // Books & Literary Club motifs: open book, stacked books, reading lamp, glasses, globe, quill
    switch (variant) {
      case 0:
        return (
          <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
            <path d="M8 9C14 9 20 10 24 13C28 10 34 9 40 9V25C34 25 28 26 24 28C20 26 14 25 8 25V9Z" fill={isDarkSurface ? '#FEF3C7' : '#FFFFFF'} stroke={stroke} strokeWidth="1.5" />
            <line x1="24" y1="13" x2="24" y2="28" stroke={stroke} strokeWidth="1.5" />
          </svg>
        );
      case 1:
        return (
          <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
            <rect x="10" y="9" width="28" height="5" rx="1" fill={rose} stroke={stroke} strokeWidth="1.2" />
            <rect x="12" y="15" width="26" height="5" rx="1" fill={accent} stroke={stroke} strokeWidth="1.2" />
            <rect x="9" y="21" width="29" height="5" rx="1" fill={secondary} stroke={stroke} strokeWidth="1.2" />
          </svg>
        );
      case 2:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M16 14L20 6H28L32 14H16Z" fill={accent} stroke={stroke} strokeWidth="1.4" />
            <line x1="24" y1="14" x2="24" y2="26" stroke={stroke} strokeWidth="2" />
            <line x1="18" y1="26" x2="30" y2="26" stroke={stroke} strokeWidth="2" strokeLinecap="round" />
          </svg>
        );
      case 3:
        return (
          <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
            <circle cx="16" cy="18" r="6" stroke={stroke} strokeWidth="1.8" fill={isDarkSurface ? 'rgba(255,255,255,0.15)' : 'rgba(255,255,255,0.7)'} />
            <circle cx="32" cy="18" r="6" stroke={stroke} strokeWidth="1.8" fill={isDarkSurface ? 'rgba(255,255,255,0.15)' : 'rgba(255,255,255,0.7)'} />
            <path d="M22 18H26" stroke={stroke} strokeWidth="1.8" />
          </svg>
        );
      case 4:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <circle cx="24" cy="15" r="9" fill={secondary} stroke={stroke} strokeWidth="1.4" />
            <path d="M15 15H33M24 6C27 10 27 20 24 24" stroke={stroke} strokeWidth="1.2" />
            <path d="M18 27H30" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        );
      default:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M13 26L33 6C36 9 34 16 26 20L13 26Z" fill={accent} stroke={stroke} strokeWidth="1.4" />
            <line x1="12" y1="27" x2="36" y2="27" stroke={stroke} strokeWidth="1.4" strokeLinecap="round" />
          </svg>
        );
    }
  }

  if (kind === TaskKind.TASK_5_USE_OF_ENGLISH_VOCAB) {
    // Ocean motifs: scallop shell, starfish, sailboat, pearl oyster, anchor, wave
    switch (variant) {
      case 0:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M11 19C11 11 17 7 24 7C31 7 37 11 37 19L30 26H18L11 19Z" fill={rose} stroke={stroke} strokeWidth="1.4" />
            <path d="M24 7V25M18 9L21 25M30 9L27 25" stroke={stroke} strokeWidth="1.1" />
          </svg>
        );
      case 1:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path
              d="M24 5L27.5 13.5L36.5 14.2L29.5 19.8L31.8 28.5L24 23.8L16.2 28.5L18.5 19.8L11.5 14.2L20.5 13.5L24 5Z"
              fill={accent}
              stroke={stroke}
              strokeWidth="1.3"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 2:
        return (
          <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
            <path d="M11 22H37L33 27H15L11 22Z" fill={stroke} />
            <path d="M24 6V21" stroke={stroke} strokeWidth="1.5" />
            <path d="M24 7L35 19H24V7Z" fill="#FEF3C7" stroke={stroke} strokeWidth="1.2" />
          </svg>
        );
      case 3:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <path d="M12 20C14 14 19 11 24 11C29 11 34 14 36 20H12Z" fill={secondary} stroke={stroke} strokeWidth="1.3" />
            <circle cx="24" cy="20" r="4.2" fill="#FFFFFF" stroke={stroke} strokeWidth="1.3" />
            <path d="M12 22H36C34 26 29 27 24 27C19 27 14 26 12 22Z" fill={secondary} stroke={stroke} strokeWidth="1.3" />
          </svg>
        );
      case 4:
        return (
          <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
            <circle cx="24" cy="9" r="3" stroke={stroke} strokeWidth="1.6" />
            <line x1="24" y1="12" x2="24" y2="26" stroke={stroke} strokeWidth="1.8" />
            <line x1="18" y1="15" x2="30" y2="15" stroke={stroke} strokeWidth="1.8" />
            <path d="M14 21C15 26 20 28 24 28C28 28 33 26 34 21" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        );
      default:
        return (
          <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
            <path d="M8 18C12 13 16 13 20 18C24 23 28 23 32 18C35 14 38 14 40 17" stroke={secondary} strokeWidth="2.4" strokeLinecap="round" />
            <path d="M10 24C14 20 18 20 22 24C26 27 30 27 34 24" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        );
    }
  }

  // Task 6: Space motifs — rocket, Saturn, crescent moon, telescope, atom/orbit, star
  switch (variant) {
    case 0:
      return (
        <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
          <path d="M24 5C29 9 31 15 30 22H18C17 15 19 9 24 5Z" fill={isDarkSurface ? '#E0E7FF' : '#FFFFFF'} stroke={stroke} strokeWidth="1.4" />
          <circle cx="24" cy="14" r="2.5" fill={secondary} stroke={stroke} strokeWidth="1.1" />
          <path d="M18 19L13 23L18 22M30 19L35 23L30 22" stroke={rose} strokeWidth="1.6" strokeLinejoin="round" />
          <path d="M21 23L24 28L27 23" fill={accent} />
        </svg>
      );
    case 1:
      return (
        <svg viewBox="0 0 48 32" className="w-10 h-6" fill="none" aria-hidden="true">
          <circle cx="24" cy="16" r="7" fill={accent} stroke={stroke} strokeWidth="1.4" />
          <ellipse cx="24" cy="16" rx="15" ry="4" transform="rotate(-16 24 16)" stroke={stroke} strokeWidth="1.6" />
        </svg>
      );
    case 2:
      return (
        <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
          <path d="M27 7C21 8 17 13 18 19C19 24 24 27 29 26C24 25 22 21 22 16C22 12 24 9 27 7Z" fill={accent} stroke={stroke} strokeWidth="1.4" />
        </svg>
      );
    case 3:
      return (
        <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
          <path d="M14 21L32 9L35 13L17 24L14 21Z" fill={secondary} stroke={stroke} strokeWidth="1.4" />
          <path d="M24 17L19 28M24 17L29 28" stroke={stroke} strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      );
    case 4:
      return (
        <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
          <circle cx="24" cy="16" r="2.5" fill={accent} />
          <ellipse cx="24" cy="16" rx="13" ry="5" transform="rotate(30 24 16)" stroke={stroke} strokeWidth="1.3" />
          <ellipse cx="24" cy="16" rx="13" ry="5" transform="rotate(-30 24 16)" stroke={stroke} strokeWidth="1.3" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 48 32" className="w-9 h-6" fill="none" aria-hidden="true">
          <path
            d="M24 5L27 13L35 16L27 19L24 27L21 19L13 16L21 13L24 5Z"
            fill={accent}
            stroke={stroke}
            strokeWidth="1.3"
            strokeLinejoin="round"
          />
        </svg>
      );
  }
};
