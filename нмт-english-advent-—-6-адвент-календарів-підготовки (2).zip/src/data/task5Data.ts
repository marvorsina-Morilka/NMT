import { Task56Test } from '../types/nmt';
import { randomizeMcqOptions } from '../utils/shuffle';

const TOPICS_3_TO_31 = [
  'Urban Gardening',
  'Space Exploration',
  'Ancient Libraries',
  'Ocean Protection',
  'Artificial Intelligence',
  'The Rise of E-books',
  'Bicycle Boom',
  'Volcanic Islands',
  'Solar Energy',
  'Wild Honeybees',
  'The Power of Music',
  'Deep Sea Creatures',
  'Virtual Reality',
  'The Art of Cooking',
  'Mountain Trekking',
  'Historic Castles',
  'Modern Architecture',
  'Language Learning',
  'Recycling Revolutions',
  'Wildlife Sanctuaries',
  'Public Transportation',
  'Board Game Renaissance',
  'Street Photography',
  'Sustainable Fashion',
  'Space Telescopes',
  'The Wonders of Tea',
  'Clean Water Projects',
  'Traditional Crafts',
  'Robotics in Medicine',
];

const RAW_TEST_1: Task56Test = {
  id: 1,
  title: 'National Rescue Dog Day',
  text: 'National Rescue Dog Day was (23) _________ in 2018 by Lisa Wiehebrink, children’s book author and Executive Director of Tails That Teach, an organisation that helps children learn the kind and proper (24) _________ of their pets. Lisa’s inspiration for National Rescue Dog Day came from her beloved dog Cooper who was (25) _________ as a puppy from a shelter after being found living on the streets. Rescue dogs are truly remarkable! They (26) _________ extreme challenges and are incredibly life-loving. They make wonderful family pets and a child’s best friend. But, rescue dogs are (27) _________ of much more. The possibilities are endless, but most of all, they are love in the purest form.',
  questions: [
    {
      num: 23,
      options: [
        { letter: 'A', text: 'made' },
        { letter: 'B', text: 'settled' },
        { letter: 'C', text: 'named' },
        { letter: 'D', text: 'established' },
      ],
      correct: 'D',
    },
    {
      num: 24,
      options: [
        { letter: 'A', text: 'attention' },
        { letter: 'B', text: 'attitude' },
        { letter: 'C', text: 'treatment' },
        { letter: 'D', text: 'relationship' },
      ],
      correct: 'C',
    },
    {
      num: 25,
      options: [
        { letter: 'A', text: 'carried' },
        { letter: 'B', text: 'adopted' },
        { letter: 'C', text: 'accepted' },
        { letter: 'D', text: 'gained' },
      ],
      correct: 'B',
    },
    {
      num: 26,
      options: [
        { letter: 'A', text: 'overact' },
        { letter: 'B', text: 'overrun' },
        { letter: 'C', text: 'overcome' },
        { letter: 'D', text: 'overplay' },
      ],
      correct: 'C',
    },
    {
      num: 27,
      options: [
        { letter: 'A', text: 'skilful' },
        { letter: 'B', text: 'capable' },
        { letter: 'C', text: 'possible' },
        { letter: 'D', text: 'positive' },
      ],
      correct: 'B',
    },
  ],
};

const RAW_TEST_2: Task56Test = {
  id: 2,
  title: 'The History of Coffee Culture',
  text: 'Coffee is one of the most popular drinks in the world. Its discovery goes back to ancient goat herds in Ethiopia who (23) _________ that their animals became energetic after eating red berries. Soon, local monks began using the beans to stay (24) _________ during long prayer nights. By the 15th century, coffee had spread across the Middle East, where vibrant coffee houses were (25) _________ as centers of conversation. Coffee culture eventually reached Europe, transforming social life and (26) _________ people to gather and debate new ideas. Today, coffee remains an essential ritual that helps millions start their day with (27) _________ energy.',
  questions: [
    {
      num: 23,
      options: [
        { letter: 'A', text: 'noticed' },
        { letter: 'B', text: 'watched' },
        { letter: 'C', text: 'revealed' },
        { letter: 'D', text: 'exposed' },
      ],
      correct: 'A',
    },
    {
      num: 24,
      options: [
        { letter: 'A', text: 'alive' },
        { letter: 'B', text: 'awake' },
        { letter: 'C', text: 'aware' },
        { letter: 'D', text: 'active' },
      ],
      correct: 'B',
    },
    {
      num: 25,
      options: [
        { letter: 'A', text: 'opened' },
        { letter: 'B', text: 'launched' },
        { letter: 'C', text: 'set' },
        { letter: 'D', text: 'founded' },
      ],
      correct: 'A',
    },
    {
      num: 26,
      options: [
        { letter: 'A', text: 'encouraging' },
        { letter: 'B', text: 'insisting' },
        { letter: 'C', text: 'demanding' },
        { letter: 'D', text: 'suggesting' },
      ],
      correct: 'A',
    },
    {
      num: 27,
      options: [
        { letter: 'A', text: 'fresh' },
        { letter: 'B', text: 'new' },
        { letter: 'C', text: 'renewed' },
        { letter: 'D', text: 'raw' },
      ],
      correct: 'C',
    },
  ],
};

function buildRawTest(id: number): Task56Test {
  if (id === 1) return RAW_TEST_1;
  if (id === 2) return RAW_TEST_2;
  const topic = TOPICS_3_TO_31[id - 3] ?? `Topic Issue ${id}`;
  return {
    id,
    title: topic,
    text: `Recent studies on ${topic.toLowerCase()} suggest that modern innovation is key. Experts (23) _________ that sustainable methods can yield long-term success. Furthermore, communities are encouraged to take (24) _________ action immediately. People who get involved (25) _________ valuable experience. It is important to stay (26) _________ of environmental shifts and remain (27) _________ of making positive choices for the planet.`,
    questions: [
      {
        num: 23,
        options: [
          { letter: 'A', text: 'claim' },
          { letter: 'B', text: 'demand' },
          { letter: 'C', text: 'tell' },
          { letter: 'D', text: 'speak' },
        ],
        correct: 'A',
      },
      {
        num: 24,
        options: [
          { letter: 'A', text: 'direct' },
          { letter: 'B', text: 'straight' },
          { letter: 'C', text: 'prompt' },
          { letter: 'D', text: 'quick' },
        ],
        correct: 'A',
      },
      {
        num: 25,
        options: [
          { letter: 'A', text: 'earn' },
          { letter: 'B', text: 'gain' },
          { letter: 'C', text: 'win' },
          { letter: 'D', text: 'catch' },
        ],
        correct: 'B',
      },
      {
        num: 26,
        options: [
          { letter: 'A', text: 'aware' },
          { letter: 'B', text: 'known' },
          { letter: 'C', text: 'familiar' },
          { letter: 'D', text: 'clear' },
        ],
        correct: 'A',
      },
      {
        num: 27,
        options: [
          { letter: 'A', text: 'willing' },
          { letter: 'B', text: 'capable' },
          { letter: 'C', text: 'ready' },
          { letter: 'D', text: 'able' },
        ],
        correct: 'B',
      },
    ],
  };
}

export function getTask5Test(testId: number, shuffleNonce = 0): Task56Test {
  const raw = buildRawTest(testId);
  return {
    ...raw,
    questions: raw.questions.map((q) => {
      const shuffled = randomizeMcqOptions(
        q.options,
        q.correct,
        `task5-test-${testId}-q-${q.num}-nonce-${shuffleNonce}`
      );
      return {
        ...q,
        options: shuffled.options,
        correct: shuffled.correct,
      };
    }),
  };
}

export function getAllTask5Tests(shuffleMap: Record<string, number> = {}): Task56Test[] {
  return Array.from({ length: 31 }, (_, i) => {
    const id = i + 1;
    return getTask5Test(id, shuffleMap[`task5_${id}`] ?? 0);
  });
}
