import { Task1Test } from '../types/nmt';
import { randomizeMatchingChoices } from '../utils/shuffle';

const TOPIC_SETS = [
  [
    {
      title: 'TASTE OF ITALY',
      body: 'Join our interactive master class and learn the secrets of making authentic Italian pasta and Neapolitan pizza from scratch. Perfect for food lovers of all experience levels.',
    },
    {
      title: 'TECHWAVE SOLUTIONS',
      body: 'Are you a natural problem solver? We are hiring a Senior Software Engineer to join our fast-growing development team. 5+ years experience required.',
    },
    {
      title: 'POTTERY FOR EVERYONE',
      body: 'Discover the relaxing art of ceramics! In this weekend workshop, you will learn basic clay shaping, glazing, and firing techniques. All tools provided.',
    },
    {
      title: 'GREEN EARTH INITIATIVE',
      body: 'Small actions lead to big changes! Join our weekend tree-planting campaign in the city park. Protect nature, clean up the environment, and meet new people.',
    },
    {
      title: 'NATIONAL SCIENCE MUSEUM',
      body: 'Explore the wonders of modern technology and space exploration through interactive exhibitions. Highlights include a walk-through Mars station and 3D planetarium.',
    },
  ],
  [
    {
      title: "THE BAKER'S CORNER",
      body: 'Come and taste our freshly baked artisan breads, organic croissants, and aromatic coffee. Made daily with 100% natural ingredients.',
    },
    {
      title: 'BRIGHT HORIZONS ACCOUNTING',
      body: 'Are you detail-oriented and experienced in finance? We are looking for a certified accountant to manage corporate tax reports.',
    },
    {
      title: 'URBAN DANCE STUDIO',
      body: 'Step up your rhythm! Whether you are a total beginner or an advanced dancer, our hip-hop and contemporary dance classes will keep you fit.',
    },
    {
      title: 'ANIMAL RESCUE LEAGUE',
      body: 'Volunteer at our weekend animal shelter adoption drive, help walk rescue dogs, or donate pet food to make a real difference.',
    },
    {
      title: 'ROYAL ART GALLERY',
      body: 'Step into 19th-century impressionism. Discover our exclusive exhibition featuring rare masterpieces by Monet, Renoir, and Van Gogh.',
    },
  ],
  [
    {
      title: 'MEDITERRANEAN BASTION',
      body: 'Enjoy a cozy evening with traditional Greek and Spanish culinary masterpieces. Fresh seafood platters and handmade tapas served daily.',
    },
    {
      title: 'GLOBAL LOGISTICS CORP',
      body: 'Looking for a career shift? We are hiring customer support specialists with fluent English and German. Full training and remote work options.',
    },
    {
      title: 'MASTERING DIGITAL PHOTOGRAPHY',
      body: 'Unlock the full potential of your camera! Learn composition, lighting, landscape photography, and photo editing software.',
    },
    {
      title: 'YOUTH BLOOD DRIVE',
      body: "Be someone's hero today! Donating blood takes only 30 minutes, but it can save up to three lives. Free health check-up included.",
    },
    {
      title: 'METROPOLITAN HISTORY MUSEUM',
      body: 'Travel back in time to the Middle Ages. Explore authentic knight armor, royal crowns, medieval weapons, and rare manuscripts.',
    },
  ],
];

const TEST_31_SET = [
  {
    title: 'ARTISAN PASTRY STUDIO',
    body: 'Treat yourself to warm French pastries, handmade tarts, and specialty espresso blends prepared fresh every morning by master bakers.',
  },
  {
    title: 'NORDIC DESIGN STUDIO',
    body: 'We are seeking a creative UI/UX Designer to join our remote product team. Competitive salary, flexible hours, and international projects.',
  },
  {
    title: 'WATERCOLOR & SKETCHING CLUB',
    body: 'Learn expressive watercolor landscapes and urban sketching techniques with step-by-step guidance. Suitable for beginners and hobbyists.',
  },
  {
    title: 'RIVERBANK CLEANUP DAY',
    body: 'Join local volunteers this Saturday morning to restore the riverside park, sort recyclables, and help protect native wildlife habitats.',
  },
  {
    title: 'OBSERVATORY & SPACE CENTER',
    body: 'Discover distant galaxies through historic telescopes and explore our interactive astronomy exhibition open daily for students and families.',
  },
];

const BASE_OPTIONS = [
  { letter: 'A', text: 'enjoy delicious food or baking' },
  { letter: 'B', text: 'find employment or a new job opportunity' },
  { letter: 'C', text: 'learn creative art, crafting or photography' },
  { letter: 'D', text: 'volunteer for environmental or social causes' },
  { letter: 'E', text: 'visit an educational exhibition or museum' },
  { letter: 'F', text: 'buy sports equipment or rent bicycles' },
  { letter: 'G', text: 'learn a new foreign language online' },
  { letter: 'H', text: 'buy real estate property' },
];

const BASE_KEYS: Record<number, string> = {
  1: 'A',
  2: 'B',
  3: 'C',
  4: 'D',
  5: 'E',
};

export function getTask1Test(testId: number, shuffleNonce = 0): Task1Test {
  const index = Math.max(0, Math.min(30, testId - 1));
  const set = testId === 31 ? TEST_31_SET : TOPIC_SETS[index % 3];
  const shuffled = randomizeMatchingChoices(
    BASE_OPTIONS,
    BASE_KEYS,
    `task1-test-${testId}-nonce-${shuffleNonce}`
  );

  return {
    id: testId,
    title: `${set[0].title} & ${set[4].title}`,
    texts: set.map((item, idx) => ({
      id: idx + 1,
      title: item.title,
      text: item.body,
    })),
    options: shuffled.choices,
    keys: shuffled.correct,
  };
}

export function getAllTask1Tests(shuffleMap: Record<string, number> = {}): Task1Test[] {
  return Array.from({ length: 31 }, (_, i) => {
    const id = i + 1;
    return getTask1Test(id, shuffleMap[`task1_${id}`] ?? 0);
  });
}
