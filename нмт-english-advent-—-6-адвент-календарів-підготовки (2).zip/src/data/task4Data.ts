import { Task4Test } from '../types/nmt';
import { randomizeMatchingChoices } from '../utils/shuffle';

const TEST_TITLES_2_TO_31 = [
  'THE POWER OF DIGITAL COMMUNICATION',
  'HOW LIFELONG LEARNING SHAPES CAREERS',
  'EXPLORING THE BEAUTY OF NATIONAL PARKS',
  'THE REVOLUTION OF SPACE EXPLORATION',
  'MODERN SCHOOLS AND INNOVATIVE TEACHING',
  'ARTIFICIAL INTELLIGENCE IN DAILY LIFE',
  'PRESERVING ANCIENT FORESTS FOR FUTURE GENERATIONS',
  'THE GLOBAL REVIVAL OF MUSIC FESTIVALS',
  'NUTRITION AND ITS IMPACT ON WELL-BEING',
  'THE EVOLUTION OF MODERN ART GALLERIES',
  'OCEAN CONSERVATION AND MARINE LIFE',
  'WHY HIKING IN MOUNTAINS RECHARGES MINDS',
  'ARCHITECTURE FOR SUSTAINABLE CITIES',
  'SCIENTIFIC DISCOVERIES OF THE 21st CENTURY',
  'THE PSYCHOLOGY OF ATHLETIC EXCELLENCE',
  'HISTORICAL HERITAGE AND TOURISM',
  'THE MAGIC OF THEATRE AND CINEMA',
  'RENEWABLE ENERGY SOURCES AROUND THE WORLD',
  'HOW READING BOOKS EXPANDS HORIZONS',
  'CREATIVITY AND PERSONAL GROWTH',
  'THE ROLE OF LEADERSHIP IN TEAM SUCCESS',
  'THE UNEXPLORED WONDERS OF THE PACIFIC OCEAN',
  'STARTUPS AND YOUNG ENTREPRENEURS',
  'VOLUNTEERING AND COMMUNITY DEVELOPMENT',
  'THE POPULARITY OF AUDIOBOOKS AND PODCASTS',
  'SAFEGUARDING WORLD HERITAGE MONUMENTS',
  'THE RISE OF WINTER EXPEDITIONS',
  'URBAN GREEN SPACES IN MODERN METROPOLISES',
  'THE IMPORTANCE OF MENTAL RESILIENCE',
  'TEAMWORK IN THE MODERN WORKPLACE',
];

const RAW_TEST_1: Task4Test = {
  id: 1,
  title: 'WHY DO WE LIKE TO WATCH SPORTS COMPETITIONS?',
  paragraphs: [
    'Why do we like to watch sports competitions? Even people (17) ______ often find themselves in front of the TV, watching football and tennis, basketball and rugby. Sports fans around the world watch with excitement their favourite team play (18) ______ .',
    'One of the main reasons people like to watch competitions is because they tend to identify themselves with the winners. When they watch the precise moves of Rafael Nadal or Elina Svitolina, see the winning game of the Champions League, they feel (19) ______ and brought a victory to their team. Winners get attention from the media and the public, they are interviewed, they appear on TV - the public enjoys watching the known faces. A fan, (20) ______ , likes to see the UEFA Cup, because he can identify himself with the top professionals.',
    "Another reason is the unpredictability of sports games. You can never know (21) ______ , which forces you to sit tightly and wait for the crucial moment, which designates all the twists and turns of the game. The course of a sports game is always unpredictable: although you can make bets and try to guess today's winner, it is never certain, which makes the game interesting to watch.",
    "A different, but also important reason for watching sports has to do with national identity. When the British watch Liverpool and Chelsea groups, they tend to identify themselves with the players and see all the failures and winnings as if they were their own. Sports games are nowadays considered to be one of the most important factors (22) ______ .",
  ],
  choices: [
    { letter: 'A', text: 'how he solves the mystery of the game' },
    { letter: 'B', text: 'how the game will end' },
    { letter: 'C', text: 'who may have never played football in his life' },
    { letter: 'D', text: 'who never engage in physical activity' },
    { letter: 'E', text: 'as if they themselves performed the brilliant move' },
    { letter: 'F', text: "that help to raise the person's national identity" },
    { letter: 'G', text: 'and never miss a single competition' },
    { letter: 'H', text: 'and think about it while watching tennis or football' },
  ],
  correct: { 17: 'D', 18: 'G', 19: 'E', 20: 'C', 21: 'B', 22: 'F' },
};

function buildRawTest(id: number): Task4Test {
  if (id === 1) return RAW_TEST_1;
  const topic = TEST_TITLES_2_TO_31[id - 2] ?? `GLOBAL TRENDS ${id}`;
  return {
    id,
    title: topic,
    paragraphs: [
      `In recent years, the concept of ${topic.toLowerCase()} has attracted widespread attention. Researchers (17) ______ point out that modern advancements offer unprecedented opportunities for society. As communities continue to grow, individuals (18) ______ find new ways to connect and exchange valuable knowledge.`,
      `One essential benefit lies in personal development. When individuals engage with inspiring initiatives, they feel (19) ______ and experience a deep sense of accomplishment. Furthermore, experts (20) ______ emphasize that consistent effort leads to remarkable long-term achievements.`,
      `Another key element is the element of surprise and innovation. Nobody can predict with certainty (21) ______ , which keeps enthusiasts engaged and motivated. This uncertainty fosters creative problem-solving and encourages active participation across all age groups.`,
      `Finally, cultural and community connections play a vital role. By working together toward shared goals, people build stronger bonds that unite diverse groups. Today, these collaborative efforts are viewed as key drivers (22) ______ .`,
    ],
    choices: [
      { letter: 'A', text: 'how the entire project will develop in the future' },
      { letter: 'B', text: 'who dedicate their careers to studying social trends' },
      { letter: 'C', text: 'who might have never considered this opportunity before' },
      { letter: 'D', text: 'as if they actively contributed to creating global success' },
      { letter: 'E', text: 'and regularly attend community workshops and discussions' },
      { letter: 'F', text: 'that help strengthen mutual trust and cultural identity' },
      { letter: 'G', text: 'how to solve complex technological challenges instantly' },
      { letter: 'H', text: 'and reflect on these achievements during daily activities' },
    ],
    correct: { 17: 'B', 18: 'E', 19: 'D', 20: 'C', 21: 'A', 22: 'F' },
  };
}

export function getTask4Test(testId: number, shuffleNonce = 0): Task4Test {
  const raw = buildRawTest(testId);
  const shuffled = randomizeMatchingChoices(
    raw.choices,
    raw.correct,
    `task4-test-${testId}-nonce-${shuffleNonce}`
  );
  return {
    ...raw,
    choices: shuffled.choices,
    correct: shuffled.correct,
  };
}

export function getAllTask4Tests(shuffleMap: Record<string, number> = {}): Task4Test[] {
  return Array.from({ length: 31 }, (_, i) => {
    const id = i + 1;
    return getTask4Test(id, shuffleMap[`task4_${id}`] ?? 0);
  });
}
