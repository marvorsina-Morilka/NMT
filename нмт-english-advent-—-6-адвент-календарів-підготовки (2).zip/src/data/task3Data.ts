import { Task3Test } from '../types/nmt';
import { randomizeMatchingChoices } from '../utils/shuffle';

const TEST_THEMES_2_TO_31 = [
  'GREEN START-UP INNOVATORS',
  'COMMUNITY ECO-VOLUNTEERS',
  'TECH DISRUPTORS OF TODAY',
  'CREATIVE DIGITAL ARTISTS',
  'UNIQUE UNIVERSITY COURSES',
  'UNUSUAL MUSEUMS AROUND THE WORLD',
  'EXTREME ATHLETES AND ADVENTURERS',
  'TOP TRAVEL DESTINATIONS',
  'YOUTH SOCIAL INITIATIVES',
  'INNOVATIVE MUSIC FESTIVALS',
  'MARINE CONSERVATION HEROES',
  'NEXT-GEN SPACE PIONEERS',
  'YOUNG SCIENTIFIC DISCOVERIES',
  'INTERNATIONAL CULTURAL EVENTS',
  'YOUNG BUSINESS LEADERS',
  'MODERN EDUCATION REFORMERS',
  'ROBOTICS AND AI INVENTORS',
  'WILDLIFE GUARDIANS',
  'HEALTH AND NUTRITION ADVOCATES',
  'WILDERNESS AND MOUNTAIN GUIDES',
  'YOUTH MENTORSHIP PROGRAMS',
  'DIGITAL CONTENT CREATORS',
  'SPORTS CHAMPIONS OF THE YEAR',
  'FOREST PRESERVATION LEADERS',
  'CULTURAL HERITAGE PRESERVERS',
  'FUTURE ARCHITECTURE VISIONARIES',
  'CLEAN ENERGY CHAMPIONS',
  'LIFELONG LEARNING ADVOCATES',
  'INNOVATIVE STUDENT PROJECTS',
  'GLOBAL YOUTH LEADERS',
];

const RAW_TEST_1: Task3Test = {
  id: 1,
  title: 'YOUNG EXPLORERS',
  items: [
    {
      num: 11,
      name: 'Charlie Smith',
      text: 'At 20 years old, expedition leader Charlie Smith was the youngest person to have crossed Iceland from north to south unsupported. Charlie was also part of the Coldest Crossing team who attempted to complete the first mid-winter, unsupported crossing of Iceland on an 18-day, 250-mile journey. However, the attempt went wrong. Soon after starting their journey, one of the hikers was flown back to Britain as he was suffering from a bad infection. A second from the team suffered frostbite to his toes and had to return. The rest of the group were rescued by the helicopter in the approaching storm.',
    },
    {
      num: 12,
      name: 'Laura Bingham',
      text: 'In 2014, 23-year-old Laura Bingham sailed across the Atlantic Ocean on a 38ft trimaran. Most recently, she cycled 7,000 km across South America with no money, raising money and awareness for Operation South America - a charity that looks after homeless girls and young women in Paraguay. She says she wanted to try and find out the ways in which some people around the world live and what it’s like to not have anything, to experience how it felt to feel real hunger and the fear of not having food or shelter. She now knows it’s terrifying.',
    },
    {
      num: 13,
      name: 'Sophie Rooney',
      text: 'In 2016, Sophie Rooney set off with the bold intention of becoming the first woman to run the length of Scandinavia - 3,000 km in 103 days! Initially accompanied by a fellow trail runner, Sophie earned everything she needed on her back, with bears being top of her worries. However, she soon found that these big grizzly creatures were the least of her concerns. In the first month alone, she had to battle extreme tiredness, dehydration, hunger and eventually illness. However, not willing to give in Sophie pushed on, often against the advice she received from people back home.',
    },
    {
      num: 14,
      name: 'Calum Muskett',
      text: 'A professional climber, mountain instructor and writer, 22-year-old Calum Muskett has climbed big walls and mountains across the world. He grew up on the very edge of the Carneddau mountain range, which hugely influenced his development as a climber and his love of mountain sports. Since his first outings, Calum has travelled all over the world free climbing, only using simple ropes for protection. He is a well published outdoor writer with feature articles published by the biggest climbing magazines. Calum is also a British Mountain Guide and holds the UK’s Winter Mountaineering and Climbing Instructor qualification - the two highest mountaineering qualifications in the UK.',
    },
    {
      num: 15,
      name: 'Agnes Plesner Skarup',
      text: 'Aged 27, Agnes Plesner Skarup is an adventurer from Denmark, whose incredible journeys have taken her across some of the most rugged and remote landscapes in the world. Aged 18, she decided to drop out of high school to hike 2,800 kilometres of America’s Pacific Crest Trail. Agnes did go back to school and upon finishing it at 21 she spontaneously bought a motorcycle and rode 25,000 kilometres around Australia. When her motorcycle got stolen, the story made national news, and a kind local gifted her his bike to finish her epic trip.',
    },
    {
      num: 16,
      name: 'Alex Mostert',
      text: 'Aged 30, Alex Mostert from the Netherlands has travelled to over 60 countries across nearly every continent, making him a true global adventurer. His adventures include surviving five days in Borneo in a native tribe. His experiences with wild orangutans and deadly snakes in the jungle sharpened his survival instincts. Aside from jungle survival, Alex is also an entrepreneur, combining his love of travel with his keen business insight. Fluent in five languages and constantly learning, he has fostered connections with people from all walks of life, hosting travellers in Amsterdam and exchanging cultural experiences along the way.',
    },
  ],
  choices: [
    { letter: 'A', text: 'became a victim of theft' },
    { letter: 'B', text: 'experienced health problems on the way' },
    { letter: 'C', text: 'was attacked by a grizzly bear' },
    { letter: 'D', text: 'is a well-known print journalist' },
    { letter: 'E', text: 'is doing a degree in photography' },
    { letter: 'F', text: 'collected funds for a non-profit organisation' },
    { letter: 'G', text: 'faced the challenges of the tropical forest' },
    { letter: 'H', text: 'was stopped by rough weather' },
  ],
  correct: { 11: 'H', 12: 'F', 13: 'B', 14: 'D', 15: 'A', 16: 'G' },
};

function buildRawTest(id: number): Task3Test {
  if (id === 1) return RAW_TEST_1;
  const themeTitle = TEST_THEMES_2_TO_31[id - 2] ?? `COMMUNITY CHAMPIONS ${id}`;
  const tag = themeTitle.split(' ')[0];
  return {
    id,
    title: themeTitle,
    items: [
      {
        num: 11,
        name: `Participant 11 (${tag})`,
        text: 'A passionate specialist who led an initiative focused on sustainable development. Their team worked tirelessly to overcome severe weather and resource limitations, delivering practical solutions to local communities.',
      },
      {
        num: 12,
        name: `Participant 12 (${tag})`,
        text: 'A dedicated campaigner who organized international crowdfunding projects. Through public workshops and media coverage, thousands of dollars were raised for community support.',
      },
      {
        num: 13,
        name: `Participant 13 (${tag})`,
        text: 'An ambitious runner and explorer who faced extreme conditions and physical exhaustion during a solo journey, proving remarkable endurance.',
      },
      {
        num: 14,
        name: `Participant 14 (${tag})`,
        text: 'An expert outdoor instructor and author whose articles appear in leading international publications. Holds highest professional certifications in their field.',
      },
      {
        num: 15,
        name: `Participant 15 (${tag})`,
        text: 'A traveler who gained nationwide news attention after suffering property theft during an expedition, before receiving unexpected support from local residents.',
      },
      {
        num: 16,
        name: `Participant 16 (${tag})`,
        text: 'A global traveler fluent in multiple languages who survived challenging tropical environments and continues to host cultural exchanges in their home city.',
      },
    ],
    choices: [
      { letter: 'A', text: 'experienced unexpected property loss on their journey' },
      { letter: 'B', text: 'faced physical fatigue and health challenges during the run' },
      { letter: 'C', text: 'suffered injuries from wild animals' },
      { letter: 'D', text: 'publishes articles in major outdoor and specialized magazines' },
      { letter: 'E', text: 'studies professional photography abroad' },
      { letter: 'F', text: 'raised funds for charitable non-profit initiatives' },
      { letter: 'G', text: 'adapted to difficult conditions in tropical environments' },
      { letter: 'H', text: 'had their expedition affected by severe weather conditions' },
    ],
    correct: { 11: 'H', 12: 'F', 13: 'B', 14: 'D', 15: 'A', 16: 'G' },
  };
}

export function getTask3Test(testId: number, shuffleNonce = 0): Task3Test {
  const raw = buildRawTest(testId);
  const shuffled = randomizeMatchingChoices(
    raw.choices,
    raw.correct,
    `task3-test-${testId}-nonce-${shuffleNonce}`
  );
  return {
    ...raw,
    choices: shuffled.choices,
    correct: shuffled.correct,
  };
}

export function getAllTask3Tests(shuffleMap: Record<string, number> = {}): Task3Test[] {
  return Array.from({ length: 31 }, (_, i) => {
    const id = i + 1;
    return getTask3Test(id, shuffleMap[`task3_${id}`] ?? 0);
  });
}
