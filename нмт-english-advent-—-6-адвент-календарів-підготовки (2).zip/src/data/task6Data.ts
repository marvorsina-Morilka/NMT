import { Task56Test } from '../types/nmt';
import { randomizeMcqOptions } from '../utils/shuffle';

const AUTHORS_2_TO_31 = [
  'Mark Twain',
  'Agatha Christie',
  'Arthur Conan Doyle',
  'J.K. Rowling',
  'Ernest Hemingway',
  'Charles Dickens',
  'Jane Austen',
  'William Shakespeare',
  'Oscar Wilde',
  'George Orwell',
  'J.R.R. Tolkien',
  'Edgar Allan Poe',
  'Charlotte Bronte',
  'Ray Bradbury',
  'Stephen King',
  'Leo Tolstoy',
  'Fyodor Dostoevsky',
  'Victor Hugo',
  'Antoine de Saint-Exupery',
  'H.G. Wells',
  'Jules Verne',
  'Jack London',
  'Mary Shelley',
  'Roald Dahl',
  'Lewis Carroll',
  'Arthur C. Clarke',
  'Isaac Asimov',
  'Virginia Woolf',
  'F. Scott Fitzgerald',
  'Emily Bronte',
];

const RAW_TEST_1: Task56Test = {
  id: 1,
  title: 'Harper Lee',
  text: 'Harper Lee, believed to be one of the most influential authors to have ever existed, (28) _________ published only a single novel. Lee’s To Kill a Mockingbird was published in 1960 and became an immediate classic of literature. The novel (29) _________ racism in the American South. Its iconic characters served as role models and changed attitudes to the problem in the United States at a time when tensions (30) _________ race were high. To Kill a Mockingbird earned the Pulitzer Prize for fiction in 1961 and (31) _________ into an Academy Award-winning film in 1962, giving the story and its characters (32) _________ life and influence over the American social sphere.',
  questions: [
    {
      num: 28,
      options: [
        { letter: 'A', text: 'fame' },
        { letter: 'B', text: 'famed' },
        { letter: 'C', text: 'famous' },
        { letter: 'D', text: 'famously' },
      ],
      correct: 'D',
    },
    {
      num: 29,
      options: [
        { letter: 'A', text: 'examine' },
        { letter: 'B', text: 'examines' },
        { letter: 'C', text: 'was examined' },
        { letter: 'D', text: 'have examined' },
      ],
      correct: 'B',
    },
    {
      num: 30,
      options: [
        { letter: 'A', text: 'regard' },
        { letter: 'B', text: 'regarding' },
        { letter: 'C', text: 'regarded' },
        { letter: 'D', text: 'to regard' },
      ],
      correct: 'B',
    },
    {
      num: 31,
      options: [
        { letter: 'A', text: 'is made' },
        { letter: 'B', text: 'has been made' },
        { letter: 'C', text: 'was made' },
        { letter: 'D', text: 'had been made' },
      ],
      correct: 'C',
    },
    {
      num: 32,
      options: [
        { letter: 'A', text: 'further' },
        { letter: 'B', text: 'the further' },
        { letter: 'C', text: 'farther' },
        { letter: 'D', text: 'the farthest' },
      ],
      correct: 'A',
    },
  ],
};

function buildRawTest(id: number): Task56Test {
  if (id === 1) return RAW_TEST_1;
  const authorName = AUTHORS_2_TO_31[id - 2] ?? `Famous Author ${id}`;
  return {
    id,
    title: authorName,
    text: `${authorName}, recognized as a brilliant literary figure, (28) _________ written numerous remarkable works. Their books (29) _________ universal human themes and timeless values. At a period when social changes (30) _________ literature were dynamic, these publications inspired millions. The masterpiece received critical acclaim and (31) _________ adapted into successful theatrical plays, providing readers with (32) _________ insight into human nature.`,
    questions: [
      {
        num: 28,
        options: [
          { letter: 'A', text: 'has' },
          { letter: 'B', text: 'have' },
          { letter: 'C', text: 'had' },
          { letter: 'D', text: 'having' },
        ],
        correct: 'A',
      },
      {
        num: 29,
        options: [
          { letter: 'A', text: 'explore' },
          { letter: 'B', text: 'explores' },
          { letter: 'C', text: 'exploring' },
          { letter: 'D', text: 'explored' },
        ],
        correct: 'A',
      },
      {
        num: 30,
        options: [
          { letter: 'A', text: 'affect' },
          { letter: 'B', text: 'affecting' },
          { letter: 'C', text: 'affected' },
          { letter: 'D', text: 'to affect' },
        ],
        correct: 'B',
      },
      {
        num: 31,
        options: [
          { letter: 'A', text: 'is' },
          { letter: 'B', text: 'was' },
          { letter: 'C', text: 'has been' },
          { letter: 'D', text: 'had been' },
        ],
        correct: 'B',
      },
      {
        num: 32,
        options: [
          { letter: 'A', text: 'deep' },
          { letter: 'B', text: 'deeper' },
          { letter: 'C', text: 'deepest' },
          { letter: 'D', text: 'deeply' },
        ],
        correct: 'B',
      },
    ],
  };
}

export function getTask6Test(testId: number, shuffleNonce = 0): Task56Test {
  const raw = buildRawTest(testId);
  return {
    ...raw,
    questions: raw.questions.map((q) => {
      const shuffled = randomizeMcqOptions(
        q.options,
        q.correct,
        `task6-test-${testId}-q-${q.num}-nonce-${shuffleNonce}`
      );
      return {
        ...q,
        options: shuffled.options,
        correct: shuffled.correct,
      };
    }),
  };
}

export function getAllTask6Tests(shuffleMap: Record<string, number> = {}): Task56Test[] {
  return Array.from({ length: 31 }, (_, i) => {
    const id = i + 1;
    return getTask6Test(id, shuffleMap[`task6_${id}`] ?? 0);
  });
}
