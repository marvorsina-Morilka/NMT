import { useEffect, useState } from 'react';
import { AdventCalendarGrid } from './components/AdventCalendarGrid';
import { AdventOverview } from './components/AdventOverview';
import { ActiveRoute, Header } from './components/Header';
import { SummaryView } from './components/SummaryView';
import { TestWorkspace } from './components/TestWorkspace';
import { ADVENTS_CONFIG, getAdventConfig } from './data/adventsMeta';
import { CheckedMap, ShuffleSeedMap, TaskKind, UserAnswersMap } from './types/nmt';
import { makeTestKey } from './utils/nmtHelpers';

const STORAGE_ANSWERS = 'nmt_advent_answers_v1';
const STORAGE_CHECKED = 'nmt_advent_checked_v1';
const STORAGE_SHUFFLE = 'nmt_advent_shuffle_v1';

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [route, setRoute] = useState<ActiveRoute>('overview');
  const [selectedAdvent, setSelectedAdvent] = useState<TaskKind>(TaskKind.TASK_1_MATCHING_ADS);
  const [selectedDay, setSelectedDay] = useState<number>(1);

  const [userAnswers, setUserAnswers] = useState<UserAnswersMap>(() =>
    readStorage<UserAnswersMap>(STORAGE_ANSWERS, {})
  );
  const [checkedMap, setCheckedMap] = useState<CheckedMap>(() =>
    readStorage<CheckedMap>(STORAGE_CHECKED, {})
  );
  const [shuffleMap, setShuffleMap] = useState<ShuffleSeedMap>(() =>
    readStorage<ShuffleSeedMap>(STORAGE_SHUFFLE, {})
  );

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_ANSWERS, JSON.stringify(userAnswers));
    } catch {
      // Ignore storage quota errors
    }
  }, [userAnswers]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CHECKED, JSON.stringify(checkedMap));
    } catch {
      // Ignore storage quota errors
    }
  }, [checkedMap]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_SHUFFLE, JSON.stringify(shuffleMap));
    } catch {
      // Ignore storage quota errors
    }
  }, [shuffleMap]);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAdvent = (kind: TaskKind) => {
    setSelectedAdvent(kind);
    setRoute('calendar');
    scrollToTop();
  };

  const handleOpenDoor = (kind: TaskKind, dayNum: number) => {
    setSelectedAdvent(kind);
    setSelectedDay(dayNum);
    setRoute('test');
    scrollToTop();
  };

  const handleStartRandomTest = () => {
    const randomAdvent = ADVENTS_CONFIG[Math.floor(Math.random() * ADVENTS_CONFIG.length)];
    const randomDay = Math.floor(Math.random() * randomAdvent.totalTests) + 1;
    handleOpenDoor(randomAdvent.id, randomDay);
  };

  const currentKey = makeTestKey(selectedAdvent, selectedDay);

  const handleSelectAnswer = (qNum: number, letter: string) => {
    if (checkedMap[currentKey]) return;
    setUserAnswers((prev) => ({
      ...prev,
      [currentKey]: {
        ...(prev[currentKey] ?? {}),
        [qNum]: letter,
      },
    }));
  };

  const handleCheckTest = () => {
    setCheckedMap((prev) => ({
      ...prev,
      [currentKey]: true,
    }));
  };

  const handleRevealAnswers = (correctMap: Record<number, string>) => {
    setUserAnswers((prev) => ({
      ...prev,
      [currentKey]: { ...correctMap },
    }));
    setCheckedMap((prev) => ({
      ...prev,
      [currentKey]: true,
    }));
  };

  const handleResetSingleTest = () => {
    setUserAnswers((prev) => {
      const copy = { ...prev };
      delete copy[currentKey];
      return copy;
    });
    setCheckedMap((prev) => {
      const copy = { ...prev };
      delete copy[currentKey];
      return copy;
    });
  };

  const handleReshuffleSingleTest = () => {
    setShuffleMap((prev) => ({
      ...prev,
      [currentKey]: (prev[currentKey] ?? 0) + 1,
    }));
    handleResetSingleTest();
  };

  const handleReshuffleAdvent = (kind: TaskKind) => {
    const cfg = getAdventConfig(kind);
    setShuffleMap((prev) => {
      const next = { ...prev };
      for (let d = 1; d <= cfg.totalTests; d++) {
        const k = makeTestKey(kind, d);
        next[k] = (next[k] ?? 0) + 1;
      }
      return next;
    });
    setUserAnswers((prev) => {
      const next = { ...prev };
      for (let d = 1; d <= cfg.totalTests; d++) {
        delete next[makeTestKey(kind, d)];
      }
      return next;
    });
    setCheckedMap((prev) => {
      const next = { ...prev };
      for (let d = 1; d <= cfg.totalTests; d++) {
        delete next[makeTestKey(kind, d)];
      }
      return next;
    });
  };

  const handleReshuffleAll = () => {
    setShuffleMap((prev) => {
      const next = { ...prev };
      for (const cfg of ADVENTS_CONFIG) {
        for (let d = 1; d <= cfg.totalTests; d++) {
          const k = makeTestKey(cfg.id, d);
          next[k] = (next[k] ?? 0) + 1;
        }
      }
      return next;
    });
    setUserAnswers({});
    setCheckedMap({});
  };

  const handleResetAll = () => {
    setUserAnswers({});
    setCheckedMap({});
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F4] text-stone-900">
      <Header
        activeRoute={route}
        selectedAdvent={selectedAdvent}
        onNavigateOverview={() => {
          setRoute('overview');
          scrollToTop();
        }}
        onNavigateCalendar={handleOpenAdvent}
        onNavigateSummary={() => {
          setRoute('summary');
          scrollToTop();
        }}
        onStartRandomTest={handleStartRandomTest}
      />

      <main className="flex-1">
        {route === 'overview' && (
          <AdventOverview
            userAnswers={userAnswers}
            checkedMap={checkedMap}
            shuffleMap={shuffleMap}
            onSelectAdvent={handleOpenAdvent}
            onOpenSummary={() => {
              setRoute('summary');
              scrollToTop();
            }}
          />
        )}

        {route === 'calendar' && (
          <AdventCalendarGrid
            adventKind={selectedAdvent}
            userAnswers={userAnswers}
            checkedMap={checkedMap}
            shuffleMap={shuffleMap}
            onSelectAdvent={handleOpenAdvent}
            onOpenDoor={handleOpenDoor}
            onReshuffleAdvent={handleReshuffleAdvent}
            onBackOverview={() => {
              setRoute('overview');
              scrollToTop();
            }}
          />
        )}

        {route === 'test' && (
          <TestWorkspace
            adventKind={selectedAdvent}
            testId={selectedDay}
            answers={userAnswers[currentKey] ?? {}}
            isChecked={Boolean(checkedMap[currentKey])}
            shuffleNonce={shuffleMap[currentKey] ?? 0}
            onSelectAnswer={handleSelectAnswer}
            onCheckTest={handleCheckTest}
            onRevealAnswers={handleRevealAnswers}
            onResetTest={handleResetSingleTest}
            onReshuffleTest={handleReshuffleSingleTest}
            onNavigateDoor={(nextDay) => handleOpenDoor(selectedAdvent, nextDay)}
            onBackToGrid={() => {
              setRoute('calendar');
              scrollToTop();
            }}
          />
        )}

        {route === 'summary' && (
          <SummaryView
            userAnswers={userAnswers}
            checkedMap={checkedMap}
            shuffleMap={shuffleMap}
            onOpenDoor={handleOpenDoor}
            onOpenAdvent={handleOpenAdvent}
            onReshuffleAll={handleReshuffleAll}
            onResetAll={handleResetAll}
          />
        )}
      </main>

      <footer className="border-t border-stone-200 bg-[#FAF8F4] py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <span>НМТ English Advent · Завдання 1–6 · 186 тестів</span>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => {
                setRoute('overview');
                scrollToTop();
              }}
              className="hover:text-stone-900 cursor-pointer"
            >
              Усі адвенти
            </button>
            <button
              type="button"
              onClick={() => {
                setRoute('summary');
                scrollToTop();
              }}
              className="hover:text-stone-900 cursor-pointer"
            >
              Підсумки
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
