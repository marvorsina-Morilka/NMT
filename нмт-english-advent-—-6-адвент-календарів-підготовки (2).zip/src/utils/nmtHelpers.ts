import { ADVENTS_CONFIG, getAdventConfig } from '../data/adventsMeta';
import { getTask1Test } from '../data/task1Data';
import { getTask2Test } from '../data/task2Data';
import { getTask3Test } from '../data/task3Data';
import { getTask4Test } from '../data/task4Data';
import { getTask5Test } from '../data/task5Data';
import { getTask6Test } from '../data/task6Data';
import {
  CheckedMap,
  ShuffleSeedMap,
  Task1Test,
  Task2Test,
  Task3Test,
  Task4Test,
  Task56Test,
  TaskKind,
  UserAnswersMap,
} from '../types/nmt';

export function makeTestKey(taskKind: TaskKind, testId: number): string {
  return `${taskKind}_${testId}`;
}

export function getTestTitle(taskKind: TaskKind, testId: number, shuffleNonce = 0): string {
  switch (taskKind) {
    case TaskKind.TASK_1_MATCHING_ADS:
      return getTask1Test(testId, shuffleNonce).title;
    case TaskKind.TASK_2_READING_MCQ:
      return getTask2Test(testId, shuffleNonce).title;
    case TaskKind.TASK_3_MATCHING_TEXTS:
      return getTask3Test(testId, shuffleNonce).title;
    case TaskKind.TASK_4_GAP_FILL_CLAUSES:
      return getTask4Test(testId, shuffleNonce).title;
    case TaskKind.TASK_5_USE_OF_ENGLISH_VOCAB:
      return getTask5Test(testId, shuffleNonce).title;
    case TaskKind.TASK_6_USE_OF_ENGLISH_GRAMMAR:
      return getTask6Test(testId, shuffleNonce).title;
  }
}

export function getCorrectMapForTest(
  taskKind: TaskKind,
  testId: number,
  shuffleNonce = 0
): Record<number, string> {
  switch (taskKind) {
    case TaskKind.TASK_1_MATCHING_ADS: {
      const t: Task1Test = getTask1Test(testId, shuffleNonce);
      return t.keys;
    }
    case TaskKind.TASK_2_READING_MCQ: {
      const t: Task2Test = getTask2Test(testId, shuffleNonce);
      return Object.fromEntries(t.questions.map((q) => [q.num, q.correct]));
    }
    case TaskKind.TASK_3_MATCHING_TEXTS: {
      const t: Task3Test = getTask3Test(testId, shuffleNonce);
      return t.correct;
    }
    case TaskKind.TASK_4_GAP_FILL_CLAUSES: {
      const t: Task4Test = getTask4Test(testId, shuffleNonce);
      return t.correct;
    }
    case TaskKind.TASK_5_USE_OF_ENGLISH_VOCAB: {
      const t: Task56Test = getTask5Test(testId, shuffleNonce);
      return Object.fromEntries(t.questions.map((q) => [q.num, q.correct]));
    }
    case TaskKind.TASK_6_USE_OF_ENGLISH_GRAMMAR: {
      const t: Task56Test = getTask6Test(testId, shuffleNonce);
      return Object.fromEntries(t.questions.map((q) => [q.num, q.correct]));
    }
  }
}

export function calculateSingleTestScore(
  taskKind: TaskKind,
  testId: number,
  userAnswers: UserAnswersMap,
  shuffleMap: ShuffleSeedMap
): { score: number; total: number; answered: number } {
  const key = makeTestKey(taskKind, testId);
  const nonce = shuffleMap[key] ?? 0;
  const correctMap = getCorrectMapForTest(taskKind, testId, nonce);
  const answers = userAnswers[key] ?? {};
  const questionNumbers = Object.keys(correctMap).map(Number);

  let score = 0;
  let answered = 0;
  for (const qNum of questionNumbers) {
    if (answers[qNum]) {
      answered++;
      if (answers[qNum] === correctMap[qNum]) {
        score++;
      }
    }
  }

  return {
    score,
    total: questionNumbers.length,
    answered,
  };
}

export function calculateAdventStats(
  taskKind: TaskKind,
  userAnswers: UserAnswersMap,
  checkedMap: CheckedMap,
  shuffleMap: ShuffleSeedMap
): {
  completedTests: number;
  totalTests: number;
  earnedPoints: number;
  maxPoints: number;
  percent: number;
} {
  const cfg = getAdventConfig(taskKind);
  let completedTests = 0;
  let earnedPoints = 0;

  for (let id = 1; id <= cfg.totalTests; id++) {
    const key = makeTestKey(taskKind, id);
    if (checkedMap[key]) {
      completedTests++;
      const res = calculateSingleTestScore(taskKind, id, userAnswers, shuffleMap);
      earnedPoints += res.score;
    }
  }

  return {
    completedTests,
    totalTests: cfg.totalTests,
    earnedPoints,
    maxPoints: cfg.maxPoints,
    percent: cfg.maxPoints > 0 ? Math.round((earnedPoints / cfg.maxPoints) * 100) : 0,
  };
}

export function calculateGlobalStats(
  userAnswers: UserAnswersMap,
  checkedMap: CheckedMap,
  shuffleMap: ShuffleSeedMap
): {
  completedTests: number;
  totalTests: number;
  earnedPoints: number;
  maxPoints: number;
  percent: number;
} {
  let completedTests = 0;
  let totalTests = 0;
  let earnedPoints = 0;
  let maxPoints = 0;

  for (const cfg of ADVENTS_CONFIG) {
    const stats = calculateAdventStats(cfg.id, userAnswers, checkedMap, shuffleMap);
    completedTests += stats.completedTests;
    totalTests += stats.totalTests;
    earnedPoints += stats.earnedPoints;
    maxPoints += stats.maxPoints;
  }

  return {
    completedTests,
    totalTests,
    earnedPoints,
    maxPoints,
    percent: maxPoints > 0 ? Math.round((earnedPoints / maxPoints) * 100) : 0,
  };
}
