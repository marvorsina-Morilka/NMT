import { LetterOption } from '../types/nmt';

const LETTERS_4 = ['A', 'B', 'C', 'D'] as const;
const LETTERS_8 = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'] as const;

function hashSeed(input: string): number {
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  for (let i = 0; i < input.length; i++) {
    const ch = input.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507);
  h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507);
  h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)) >>> 0;
}

function createRng(seedStr: string): () => number {
  let a = hashSeed(seedStr) || 1;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffleArray<T>(items: readonly T[], rng: () => number): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }
  return arr;
}

/**
 * Shuffles 4 multiple-choice options (A-D) and updates the correct answer letter
 * so correct answers are uniformly scattered across A, B, C, and D instead of
 * clustered on A or B.
 */
export function randomizeMcqOptions(
  options: LetterOption[],
  correctLetter: string,
  seedKey: string
): { options: LetterOption[]; correct: string } {
  const rng = createRng(seedKey);
  const tagged = options.map((opt) => ({
    text: opt.text,
    isCorrect: opt.letter === correctLetter,
  }));

  const shuffled = shuffleArray(tagged, rng);
  let newCorrect = correctLetter;

  const newOptions: LetterOption[] = shuffled.map((item, idx) => {
    const letter = LETTERS_4[idx] ?? String.fromCharCode(65 + idx);
    if (item.isCorrect) {
      newCorrect = letter;
    }
    return {
      letter,
      text: item.text,
    };
  });

  return { options: newOptions, correct: newCorrect };
}

/**
 * Shuffles 8 matching/gap-fill choices (A-H) and remaps all question keys
 * so the answer mapping is randomly scattered for each test.
 */
export function randomizeMatchingChoices(
  choices: LetterOption[],
  correctMap: Record<number, string>,
  seedKey: string
): { choices: LetterOption[]; correct: Record<number, string> } {
  const rng = createRng(seedKey);
  const shuffled = shuffleArray(choices, rng);

  const oldToNew: Record<string, string> = {};
  const newChoices: LetterOption[] = shuffled.map((choice, idx) => {
    const newLetter = LETTERS_8[idx] ?? String.fromCharCode(65 + idx);
    oldToNew[choice.letter] = newLetter;
    return {
      letter: newLetter,
      text: choice.text,
    };
  });

  const newCorrect: Record<number, string> = {};
  for (const [qNumStr, oldLetter] of Object.entries(correctMap)) {
    const qNum = Number(qNumStr);
    newCorrect[qNum] = oldToNew[oldLetter] ?? oldLetter;
  }

  return { choices: newChoices, correct: newCorrect };
}
